import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from './Vendég/Navbar';
import './LandingPage.css';
import NavbarStudent from './Diák/NavbarStudent';
import DynamicNavbar from './Other/DynamicNavbar';

const LandingPage = () => {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
      setUserType(localStorage.getItem('userType'));
    }
  }, []);

  const handleKezdes = () => navigate('/munkak');
  const handleLoginRedirect = () => navigate('/login');
  const handleProfilRedirect = () => navigate('/profil');
  const handleCegDashboard = () => navigate('/ceg-profil');
  const handleUjHirdetes = () => navigate('/uj-hirdetes');

  return (
    <div className="landing-page-container">
      <DynamicNavbar />

      <section className="lp-hero">
        <div className="lp-hero-image-container">
          <img
            src="/images/hero.jpg"
            alt="Diákok beszélgetnek"
            className="lp-hero-img_placeholder"
          />
        </div>

        <div className="lp-hero-content">
          <span className="lp-badge">MÁR 500+ AKTÍV PROJEKT</span>
          <h1 className="hero-title">Váltsd az idődet <span className="highlight-blue">tapasztalatra!</span></h1>
          <p className="lp-hero-sub">
            Találd meg a tökéletes közösségi szolgálatot nálunk. Fedezz fel izgalmas lehetőségeket és építsd a jövődet, miközben segítesz másoknak.
          </p>
          <div className="lp-hero-buttons">
            <button
              className="lp-btn lp-btn-primary lp-btn-large"
              onClick={!isLoggedIn ? handleKezdes : (userType === 'ceg' ? handleCegDashboard : handleProfilRedirect)}
            >
              {isLoggedIn ? "Irányítópult" : "Kezdés most"}
            </button>
          </div>
        </div>
      </section>
      {!isLoggedIn && (
        <section className="lp-divider-text">
          <h2 className="divider-title">Csatlakozz a közösségünkhöz</h2>
          <p className="divider-subtitle">Válassz, hogy melyik oldalon szeretnél részt venni a fejlődésben.</p>
        </section>
      )}

      {!isLoggedIn && (
        <section className="lp-cards-section">
          <div className="lp-info-card">
            <div className="lp-card-icon">🎓</div>
            <h3 className="info-card-title">Diákoknak: Hogyan működik?</h3>
            <p className="info-card-text">Böngéssz több száz lehetőség között, jelentkezz egyszerűen egy kattintással, és gyűjtsd az óráidat hitelesítve, egy helyen.</p>
            <ul className="lp-check-list">
              <li>Gyors profilalkotás</li>
              <li>Automatikus igazolás generálás</li>
              <li>Értékelések a cégekről</li>
            </ul>
            <span className="lp-card-link" onClick={handleKezdes}>
              Ismerd meg a folyamatot →
            </span>
          </div>

          <div className="lp-info-card">
            <div className="lp-card-icon">💼</div>
            <h3 className="info-card-title">Cégeknek: Miért éri meg?</h3>
            <p className="info-card-text">Társadalmi felelősségvállalás, utánpótlás nevelés és teljesen digitalizált adminisztráció. Építse cége márkáját fiatal tehetségekkel.</p>
            <ul className="lp-check-list">
              <li>Egyszerű hirdetéskezelés</li>
              <li>Pozitív PR és CSR hatás</li>
              <li>Potenciális munkavállalók szűrése</li>
            </ul>
            <span className="lp-card-link" onClick={() => navigate('/cegeknek')}>
              Csatlakozz partnerként →
            </span>
          </div>
        </section>
      )}


      {isLoggedIn && userType === 'diák' && (

        <section className="lp-cards-section">
          <div className="lp-info-card">
            <div className="lp-card-icon">🎓</div>
            <h3 className="info-card-title">Diákoknak: Hogyan működik?</h3>
            <p className="info-card-text">Böngéssz több száz lehetőség között, jelentkezz egyszerűen egy kattintással, és gyűjtsd az óráidat hitelesítve, egy helyen.</p>
            <ul className="lp-check-list">
              <li>Gyors profilalkotás</li>
              <li>Automatikus igazolás generálás</li>
              <li>Értékelések a cégekről</li>
            </ul>
            <span className="lp-card-link" onClick={handleKezdes}>
              Ismerd meg a folyamatot →
            </span>
          </div>
        </section>

      )}

      {isLoggedIn && userType === 'cég' && (
        <section className="lp-cards-section">
          <div className="lp-info-card">
            <div className="lp-card-icon">💼</div>
            <h3 className="info-card-title">Cégeknek: Miért éri meg?</h3>
            <p className="info-card-text">Társadalmi felelősségvállalás, utánpótlás nevelés és teljesen digitalizált adminisztráció. Építse cége márkáját fiatal tehetségekkel.</p>
            <ul className="lp-check-list">
              <li>Egyszerű hirdetéskezelés</li>
              <li>Pozitív PR és CSR hatás</li>
              <li>Potenciális munkavállalók szűrése</li>
            </ul>
            <span className="lp-card-link" onClick={() => navigate('/cegeknek')}>
              Csatlakozz partnerként →
            </span>
          </div>
        </section>
      )}

      <section className="lp-bottom-cta">
        <div className="lp-cta-content">
          <h2>{isLoggedIn ? "Örülünk, hogy újra itt vagy!" : "Készen állsz a közösség építésére?"}</h2>
          <p>
            {!isLoggedIn && "Csatlakozz Magyarország legnagyobb közösségi szolgálati platformjához diákként vagy partnercégként még ma!"}
            {isLoggedIn && userType === 'diak' && "Nézd meg a legújabb lehetőségeket, vagy ellenőrizd a profilodon az eddig megszerzett óráidat!"}
            {isLoggedIn && userType === 'ceg' && "Hozd létre az új hirdetésed, vagy ellenőrizd az aktuális jelentkezőket a platformon!"}
          </p>
          <div className="lp-cta-buttons">
            {!isLoggedIn && (
              <>
                <button className="lp-btn lp-btn-primary" onClick={handleLoginRedirect}>Regisztráció diákként</button>
                <button className="lp-btn lp-btn-outline-light" onClick={handleLoginRedirect}>Regisztráció cégként</button>
              </>
            )}

            {isLoggedIn && userType === 'diak' && (
              <>
                <button className="lp-btn lp-btn-primary" onClick={handleProfilRedirect}>Tovább a profilomra</button>
                <button className="lp-btn lp-btn-outline-light" onClick={handleKezdes}>Munkák böngészése</button>
              </>
            )}

            {isLoggedIn && userType === 'ceg' && (
              <>
                <button className="lp-btn lp-btn-primary" onClick={handleUjHirdetes}>Új hirdetés feladása</button>
                <button className="lp-btn lp-btn-outline-light" onClick={handleCegDashboard}>Tovább a profilhoz</button>
              </>
            )}
          </div>
        </div>
      </section>

      <footer className="lp-footer">
        <div className="lp-footer-top">
          <div className="lp-footer-brand">
            <div className="lp-logo">
              <span className="logo-icon">🎓</span>
              <span className="logo-text">Ötven óra</span>
            </div>
            <p>A jövő tehetségeit kötjük össze a jelen felelősségteljes vállalataival.</p>
          </div>
          <div className="lp-footer-links">
            <h4>Platform</h4>
            <ul>

              <li onClick={() => navigate('/cegeknek')}>Hogyan működik</li>
              <li onClick={() => navigate('/segitseg')}>Gyakori kérdések</li>
            </ul>
          </div>
          <div className="lp-footer-links">
            <h4>Vállalatunk</h4>
            <ul>
              <li onClick={() => navigate('/rolunk')}>Rólunk</li>
              <li onClick={() => navigate('/segitseg')}>Kapcsolat</li>
            </ul>
          </div>
        </div>
        <div className="lp-footer-bottom">
          <p>© 2026 Ötven óra. Minden jog fenntartva.</p>
          <div className="lp-social-icons">
            <span>FB</span> <span>IG</span> <span>LI</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;