import React from 'react';
import { useNavigate } from 'react-router-dom';
import DynamicNavbar from '../Other/DynamicNavbar';
import './Cegeknek.css';

const Cegeknek = () => {
  const navigate = useNavigate();

  return (
    <div className="partner-page-container">
      <DynamicNavbar />
      <section className="partner-hero">
        <div className="partner-hero-content">
          <span className="partner-badge">Szervezeteknek és Cégeknek</span>
          <h1 className="partner-hero-title">Találja meg a jövő leglelkesebb tehetségeit!</h1>
          <p className="partner-hero-subtitle">
            Csatlakozzon az Ötven Óra hálózatához fogadó szervezetként. Egyszerűsített adminisztráció,
            motivált diákok és valódi társadalmi hatás – mindez egyetlen felületen.
          </p>
          <button className="partner-cta-btn" onClick={() => navigate('/login')}>
            Ingyenes Regisztráció
          </button>
        </div>
      </section>

      <section className="partner-benefits">
        <div className="partner-section-header">
          <h2 className="partner-section-title">Miért éri meg csatlakozni?</h2>
          <p className="partner-section-subtitle">Felejtse el a papírmunkát, mi digitalizáltuk a közösségi szolgálatot.</p>
        </div>

        <div className="partner-benefits-grid">
          <div className="partner-benefit-card">
            <div className="benefit-icon">📄</div>
            <h3>Adminisztrációmentes</h3>
            <p>A diákok jelentkezéseit és az igazolt órákat a rendszer automatikusan vezeti. Nincs több elveszett papírfecni és pecsételgetés.</p>
          </div>
          <div className="partner-benefit-card">
            <div className="benefit-icon">🎓</div>
            <h3>Közvetlen kapcsolat</h3>
            <p>Érje el a helyi középiskolásokat közvetlenül. Építsen kapcsolatot a jövő munkavállalóival már a karrierjük legelején.</p>
          </div>
          <div className="partner-benefit-card">
            <div className="benefit-icon">🌍</div>
            <h3>CSR és Társadalmi hatás</h3>
            <p>A diákok bevonásával nemcsak értékes segítséget kap, de aktívan tesz a helyi közösség fejlesztéséért is.</p>
          </div>
          <div className="partner-benefit-card">
            <div className="benefit-icon">💡</div>
            <h3>Ingyenes és Gyors</h3>
            <p>A platform használata fogadó szervezetek számára teljesen ingyenes. Pár kattintás, és már töltheti is fel az elérhető pozíciókat.</p>
          </div>
        </div>
      </section>

      <section className="partner-steps">
        <h2 className="partner-steps-title">Hogyan működik a gyakorlatban?</h2>
        <div className="partner-steps-container">
          <div className="partner-step">
            <div className="step-number">1</div>
            <h4>Regisztráció</h4>
            <p>Hozza létre szervezeti profilját pár perc alatt.</p>
          </div>
          <div className="step-connector"></div>
          <div className="partner-step">
            <div className="step-number">2</div>
            <h4>Hirdetés feladása</h4>
            <p>Írja le, miben van szüksége segítségre, és mikor.</p>
          </div>
          <div className="step-connector"></div>
          <div className="partner-step">
            <div className="step-number">3</div>
            <h4>Diákok fogadása</h4>
            <p>A fiatalok jelentkeznek, Ön pedig jóváhagyja őket.</p>
          </div>
          <div className="step-connector"></div>
          <div className="partner-step">
            <div className="step-number">4</div>
            <h4>Órák igazolása</h4>
            <p>Egy kattintással jóváírja a ledolgozott időt a rendszerben.</p>
          </div>
        </div>
      </section>

      <section className="partner-bottom-cta">
        <h2 className="bottom-cta-title">Készen áll a közös munkára?</h2>
        <p className="bottom-cta-subtitle">Csatlakozzon több tucat partnerünkhöz, és építsünk együtt egy jobb jövőt!</p>
        <button className="partner-cta-btn-light" onClick={() => navigate('/login')}>
          Regisztrálok Cégként
        </button>
      </section>
    </div>
  );
};

export default Cegeknek;