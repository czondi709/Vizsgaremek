import React, { useState } from 'react';
import DynamicNavbar from '../Other/DynamicNavbar';
import './Segitseg.css';

export default function Segitseg() {
  const [activeIndex, setActiveIndex] = useState(null);

  const faqs = [
    {
      question: "Hogyan igazolják le az óráimat?",
      answer: "A munka elvégzése után a fogadó szervezet a saját felületén egyetlen kattintással hagyja jóvá a teljesített órákat. Ez az adat automatikusan frissül a te profilodban is, így azonnal láthatod az előrehaladásod, és az iskolád is nyomon tudja követni."
    },
    {
      question: "Mennyibe kerül a regisztráció?",
      answer: "A platform használata mind a diákok, mind pedig a fogadó szervezetek számára 100%-ban ingyenes. Célunk a közösségépítés, nem pedig a profitszerzés."
    },
    {
      question: "Mit tegyek, ha elfelejtettem a jelszavam?",
      answer: "A bejelentkezési oldalon kattints az 'Elfelejtett jelszó' linkre. Add meg a regisztrált e-mail címedet, és pillanatokon belül küldünk egy biztonságos linket, amivel új jelszót állíthatsz be magadnak."
    },
    {
      question: "Kik végezhetnek közösségi szolgálatot a platformon?",
      answer: "Bármelyik magyarországi középiskolás diák regisztrálhat, akinek kötelező az 50 órás iskolai közösségi szolgálat (IKSZ) teljesítése az érettségi bizonyítvány megszerzéséhez."
    },
    {
      question: "Cégként hogyan tudok munkát meghirdetni?",
      answer: "Céges regisztráció és belépés után a Vállalati Irányítópulton az 'Új hirdetés' gombra kell kattintanod. Itt megadhatod a munka jellegét, az IKSZ kategóriát, a létszámot és az időpontot, ami azonnal kikerül a diákokhoz."
    }
  ];

  const toggleFAQ = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="help-page-container">
      <DynamicNavbar />

      <section className="help-hero">
        <div className="help-hero-content">
          <h1 className="help-hero-title">Miben segíthetünk?</h1>
          <p className="help-hero-subtitle">Összegyűjtöttük a leggyakrabban felmerülő kérdéseket, hogy gyorsan megtaláld a választ, amit keresel.</p>
        </div>
      </section>

      <section className="faq-section">
        <div className="faq-container">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className={`faq-item ${activeIndex === index ? 'active' : ''}`}
              onClick={() => toggleFAQ(index)}
            >
              <div className="faq-question">
                <h3>{faq.question}</h3>
                <span className="faq-icon">{activeIndex === index ? '−' : '+'}</span>
              </div>
              <div className="faq-answer">
                <p>{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="help-bottom-contact">
        <div className="contact-content">
          <h2 className="contact-title">Nem találtad meg a választ?</h2>
          <p className="contact-subtitle">Ügyfélszolgálatunk készséggel áll rendelkezésedre bármilyen egyedi kérdés esetén.</p>
          <a href="mailto:support@otvenora.hu" className="contact-email-btn">
            ✉️ Írj nekünk: support@otvenora.hu
          </a>
        </div>
      </section>

    </div>
  );
}