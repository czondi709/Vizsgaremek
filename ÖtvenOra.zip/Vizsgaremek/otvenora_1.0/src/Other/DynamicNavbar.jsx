import React from 'react';
import Navbar from '../Vendég/Navbar';
import NavbarStudent from '../Diák/NavbarStudent';
import NavbarCompany from '../Cég/NavbarCompany';

export default function DynamicNavbar() {
  const token = localStorage.getItem('token');
  const userType = localStorage.getItem('userType');

  if (!token) {
    return <Navbar />;
  }

  if (userType === 'ceg') {
    return <NavbarCompany />;
  } else if (userType === 'diak') {
    return <NavbarStudent />;
  }

  return <Navbar />;
}