import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DynamicNavbar from '../Other/DynamicNavbar';
import './Rolunk.css';

export default function Rolunk() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
      setUserType(localStorage.getItem('userType'));
    }
  }, []);

  return (
    <div className="about-page-container">
      <DynamicNavbar />

      <section className="about-hero">
        <div className="about-hero-content">
          <h1>Ismerd meg az Ötven Óra történetét</h1>
          <p>
            Küldetésünk, hogy a kötelező közösségi szolgálat ne egy kipipálandó teher,
            hanem egy valódi, értékteremtő élmény legyen minden diák számára.
          </p>
        </div>
      </section>

      <section className="about-mission-section">
        <div className="about-mission-text">
          <h2>Miért hoztuk létre ezt a platformot?</h2>
          <p>
            Az "Ötven Óra" projekt azért született meg, hogy <strong>digitalizálja és leegyszerűsítse</strong> a kötelező iskolai közösségi szolgálat (IKSZ) adminisztrációját.
          </p>
          <p>
            Hiszünk abban, hogy a közösségi munka nem csak egy kötelezettség az érettségi előtt. Ez egy egyedülálló lehetőség a tapasztalatszerzésre, a munka világába való belekóstolásra és a kapcsolatépítésre. Rendszerünk egy modern híd, amely zökkenőmentesen köti össze a diákokat, az iskolákat és a fogadó szervezeteket.
          </p>
        </div>
      </section>

      <section className="about-values-section">
        <h2 className="values-title">Alapértékeink</h2>
        <div className="about-values-grid">

          <div className="about-value-card">
            <div className="value-icon">🤝</div>
            <h3>Közösségépítés</h3>
            <p>Nemcsak órákat számolunk, hanem embereket kötünk össze. Célunk, hogy a helyi közösségek erősebbek legyenek a fiatalok bevonásával.</p>
          </div>

          <div className="about-value-card">
            <div className="value-icon">💻</div>
            <h3>Digitalizáció</h3>
            <p>Búcsút intünk a papíralapú, elvesző naplóknak. Gyors, átlátható és nyomon követhető rendszert biztosítunk minden résztvevőnek.</p>
          </div>

          <div className="about-value-card">
            <div className="value-icon">🌱</div>
            <h3>Jövőtudatosság</h3>
            <p>Segítünk a diákoknak olyan helyet találni, ami a jövőbeli karrierjük szempontjából is releváns tapasztalatot nyújt.</p>
          </div>

        </div>
      </section>

      <section className="about-bottom-cta">
        <div className="cta-content">
          <h2>{isLoggedIn ? "Örülünk, hogy velünk vagy!" : "Legyél te is a közösségünk része!"}</h2>
          <p>
            {!isLoggedIn
              ? "Akár diák vagy, aki órát gyűjt, akár szervezet, aki segítséget keres – itt a helyed."
              : "Folytasd a böngészést, vagy hirdess új lehetőségeket a platformon!"}
          </p>

          <div className="cta-buttons">
            {!isLoggedIn && (
              <>
                <button className="about-btn-primary" onClick={() => navigate('/login')}>Regisztrálok</button>
                <button className="about-btn-secondary" onClick={() => navigate('/munkak')}>Munkák böngészése</button>
              </>
            )}

            {isLoggedIn && userType === 'diak' && (
              <button className="about-btn-secondary" onClick={() => navigate('/munkak')}>Munkák böngészése</button>
            )}

            {isLoggedIn && userType === 'ceg' && (
              <button className="about-btn-primary" onClick={() => navigate('/uj-hirdetes')}>Új munka meghirdetése</button>
            )}
          </div>
        </div>
      </section>

    </div>
  );
}