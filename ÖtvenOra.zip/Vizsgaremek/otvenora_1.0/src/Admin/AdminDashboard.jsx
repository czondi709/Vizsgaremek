import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [adminName] = useState("Fő Adminisztrátor");

  const [activeTab, setActiveTab] = useState('iranyitopult');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false); // Mobil menü állapota

  const [pendingJobs, setPendingJobs] = useState([]);
  const [allJobs, setAllJobs] = useState([]);
  const [recentCompanies, setRecentCompanies] = useState([]);
  const [allCompanies, setAllCompanies] = useState([]);
  const [allStudents, setAllStudents] = useState([]);
  const [stats, setStats] = useState({
    diakok: 0, cegek: 0, varakozoMunkak: 0, leigazoltOrak: 0
  });
  const [loading, setLoading] = useState(true);

  const [selectedCompany, setSelectedCompany] = useState(null);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null);

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  const handleTabClick = (tab) => {
    setActiveTab(tab);
    setIsMobileMenuOpen(false);
  };

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (!token) { navigate('/login'); return; }

      try {
        const [diakRes, cegRes, munkaRes] = await Promise.all([
          axios.get('https://localhost:7259/api/Diak', { headers: { Authorization: `Bearer ${token}` } }),
          axios.get('https://localhost:7259/api/Ceg', { headers: { Authorization: `Bearer ${token}` } }),
          axios.get('https://localhost:7259/api/Munka', { headers: { Authorization: `Bearer ${token}` } })
        ]);

        const students = diakRes.data || [];
        const companies = cegRes.data || [];
        const jobs = munkaRes.data || [];

        setAllStudents(students);
        setAllCompanies(companies);
        setRecentCompanies(companies.slice(-5).reverse());
        setAllJobs(jobs);

        const waitingJobs = jobs.filter(j => j.statusz === 'fuggoben' || !j.statusz);
        setPendingJobs(waitingJobs);

        let totalHours = 0;
        students.forEach(s => {
          totalHours += (s.ledolgozott_ora || s.Ledolgozott_ora || 0);
        });

        setStats({
          diakok: students.length,
          cegek: companies.length,
          varakozoMunkak: waitingJobs.length,
          leigazoltOrak: totalHours
        });

      } catch (err) {
        console.error("Hiba az adatok letöltésekor:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

  const handleApproveJob = async (job) => {
    const token = localStorage.getItem('token');
    try {
      await axios.put(`https://localhost:7259/api/Munka/statusz/${job.munka_id}`,
        { ujStatusz: 'aktiv' },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert(`✅ "${job.munka_nev}" jóváhagyva!`);
      setPendingJobs(prev => prev.filter(j => j.munka_id !== job.munka_id));
      setSelectedJob(null);
    } catch (err) {
      alert("Hiba a jóváhagyás során.");
    }
  };

  const handleDeleteJob = async (id, nev, isFromModal = false) => {
    if (!window.confirm(`Biztosan törölni akarod a(z) "${nev}" hirdetést?`)) return;
    const token = localStorage.getItem('token');
    try {
      await axios.delete(`https://localhost:7259/api/Munka/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      setPendingJobs(prev => prev.filter(j => j.munka_id !== id));
      setAllJobs(prev => prev.filter(j => j.munka_id !== id));
      if (isFromModal) setSelectedJob(null);
      alert("Hirdetés törölve.");
    } catch (err) { alert("Hiba a törlés során."); }
  };

  const renderContent = () => {
    if (loading) return <div className="admin-loading">Adatok betöltése...</div>;

    switch (activeTab) {
      case 'iranyitopult':
        return (
          <div className="admin-content-wrapper">
            <div className="admin-stats-grid">
              <div className="stat-card">
                <div className="stat-icon">🎓</div>
                <div className="stat-info"><h3>{stats.diakok}</h3><p>Regisztrált diák</p></div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">🏢</div>
                <div className="stat-info"><h3>{stats.cegek}</h3><p>Partner intézmény</p></div>
              </div>
              <div className="stat-card warning">
                <div className="stat-icon">⏳</div>
                <div className="stat-info"><h3>{stats.varakozoMunkak}</h3><p>Várakozó hirdetés</p></div>
              </div>
              <div className="stat-card success">
                <div className="stat-icon">⏱️</div>
                <div className="stat-info"><h3>{stats.leigazoltOrak}</h3><p>Összes teljesített óra</p></div>
              </div>
            </div>

            <div className="admin-layout-grid">
              <div className="admin-card main-card">
                <div className="card-header">
                  <h2>🕒 Jóváhagyásra váró hirdetések</h2>
                  <button className="btn-text" onClick={() => handleTabClick('munkak')}>Összes hirdetés</button>
                </div>
                <div className="table-responsive">
                  <table className="admin-table">
                    <thead>
                      <tr><th>Munka megnevezése</th><th>Kategória</th><th>Óraszám</th><th>Műveletek</th></tr>
                    </thead>
                    <tbody>
                      {pendingJobs.length === 0 ? (
                        <tr><td colSpan="4" className="empty-row">Nincs várakozó hirdetés.</td></tr>
                      ) : (
                        pendingJobs.map(job => (
                          <tr key={job.munka_id}>
                            <td><strong>{job.munka_nev}</strong></td>
                            <td><span className="tag">{job.kategoria}</span></td>
                            <td>{job.oraszam} óra</td>
                            <td className="actions">
                              <button className="btn-success-small" onClick={() => handleApproveJob(job)}>Pipa</button>
                              <button className="btn-outline-small" onClick={() => setSelectedJob(job)}>Szem</button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="admin-card side-card">
                <div className="card-header"><h2>🏢 Új cégek</h2></div>
                <div className="list-items">
                  {recentCompanies.map(ceg => (
                    <div className="list-item" key={ceg.ceg_id} onClick={() => setSelectedCompany(ceg)}>
                      <div className="item-icon">🏢</div>
                      <div className="item-info"><strong>{ceg.cegnev}</strong><p>{ceg.ceg_email}</p></div>
                      <div className="item-arrow">→</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 'diakok':
        return (
          <div className="admin-card">
            <div className="card-header"><h2>🎓 Regisztrált diákok listája</h2></div>
            <div className="table-responsive">
              <table className="admin-table">
                <thead><tr><th>Név</th><th>Email</th><th>Iskola</th><th>Ledolgozott óra</th><th>Műveletek</th></tr></thead>
                <tbody>
                  {allStudents.map(s => (
                    <tr key={s.diak_id}>
                      <td><strong>{s.nev}</strong></td>
                      <td>{s.email}</td>
                      <td>{s.iskola || '-'}</td>
                      <td>{s.ledolgozott_ora || 0} óra</td>
                      <td><button className="btn-outline-small" onClick={() => setSelectedStudent(s)}>Adatlap</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'cegek':
        return (
          <div className="admin-card">
            <div className="card-header"><h2>🏢 Regisztrált cégek listája</h2></div>
            <div className="table-responsive">
              <table className="admin-table">
                <thead><tr><th>Cégnév</th><th>Email</th><th>Adószám</th><th>Cím</th><th>Műveletek</th></tr></thead>
                <tbody>
                  {allCompanies.map(c => (
                    <tr key={c.ceg_id}>
                      <td><strong>{c.cegnev}</strong></td>
                      <td>{c.ceg_email}</td>
                      <td>{c.adoszam}</td>
                      <td>{c.cim}</td>
                      <td><button className="btn-outline-small" onClick={() => setSelectedCompany(c)}>Adatlap</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'munkak':
        return (
          <div className="admin-card">
            <div className="card-header"><h2>💼 Összes munkaajánlat</h2></div>
            <div className="table-responsive">
              <table className="admin-table">
                <thead><tr><th>Megnevezés</th><th>Kategória</th><th>Státusz</th><th>Létszám</th><th>Műveletek</th></tr></thead>
                <tbody>
                  {allJobs.map(j => (
                    <tr key={j.munka_id}>
                      <td><strong>{j.munka_nev}</strong></td>
                      <td>{j.kategoria}</td>
                      <td><span className={`status-badge ${j.statusz === 'aktiv' ? 'green' : 'yellow'}`}>{j.statusz || 'fuggoben'}</span></td>
                      <td>{j.letszam} fő</td>
                      <td>
                        <button className="btn-outline-small" style={{ marginRight: '5px' }} onClick={() => setSelectedJob(j)}>Részletek</button>
                        <button className="btn-outline-small" style={{ color: '#ef4444' }} onClick={() => handleDeleteJob(j.munka_id, j.munka_nev)}>Törlés</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      default: return null;
    }
  };

  return (
    <div className="admin-container">

      <div className="mobile-header">
        <div className="mobile-brand">
          <span className="brand-icon">🛠️</span>
          <h2>Admin Panel</h2>
        </div>
        <button className="hamburger-btn" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? '✕' : '☰'}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="sidebar-overlay" onClick={() => setIsMobileMenuOpen(false)}></div>
      )}

      <aside className={`admin-sidebar ${isMobileMenuOpen ? 'open' : ''}`}>

        <button
          className="sidebar-close-btn"
          onClick={() => setIsMobileMenuOpen(false)}
          style={{ position: 'absolute', top: '20px', right: '20px', background: 'none', border: 'none', fontSize: '24px', color: '#64748b', cursor: 'pointer', zIndex: 10 }}
        >
          ✕
        </button>

        <div className="admin-brand desktop-only" onClick={() => handleTabClick('iranyitopult')} style={{ cursor: 'pointer' }}>
          <span className="brand-icon">🛠️</span><h2>Admin Panel</h2>
        </div>

        <nav className="admin-nav">
          <a className={`nav-item ${activeTab === 'iranyitopult' ? 'active' : ''}`} onClick={() => handleTabClick('iranyitopult')} style={{ cursor: 'pointer' }}>📊 Irányítópult</a>

          <div className="nav-group">
            <h3>FELHASZNÁLÓK</h3>
            <a className={`nav-item ${activeTab === 'diakok' ? 'active' : ''}`} onClick={() => handleTabClick('diakok')} style={{ cursor: 'pointer' }}>🎓 Diákok</a>
            <a className={`nav-item ${activeTab === 'cegek' ? 'active' : ''}`} onClick={() => handleTabClick('cegek')} style={{ cursor: 'pointer' }}>🏢 Cégek</a>
          </div>

          <div className="nav-group">
            <h3>KEZELÉS</h3>
            <a className={`nav-item ${activeTab === 'munkak' ? 'active' : ''}`} onClick={() => handleTabClick('munkak')} style={{ cursor: 'pointer' }}>
              💼 Munkaajánlatok {stats.varakozoMunkak > 0 && <span className="nav-badge warning">{stats.varakozoMunkak}</span>}
            </a>
          </div>

          <h3>RENDSZER</h3>
          <a className="nav-item" onClick={(e) => {
            e.preventDefault();
            localStorage.clear();
            navigate('/');
            setIsMobileMenuOpen(false);
          }} style={{ cursor: 'pointer' }}>
            🏠 Főoldal (Vendég nézet)
          </a>
        </nav>

        <div className="admin-sidebar-footer">
          <button className="admin-logout-btn" onClick={handleLogout}>🚪 Kijelentkezés</button>
        </div>
      </aside>

      <main className="admin-main">
        <header className="admin-header desktop-only">
          <h1>{activeTab === 'iranyitopult' ? 'Irányítópult' : activeTab === 'diakok' ? 'Diákok' : activeTab === 'cegek' ? 'Cégek' : 'Összes Munka'}</h1>
        </header>
        {renderContent()}
      </main>

      {selectedJob && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0,0,0,0.6)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 3000, backdropFilter: 'blur(4px)' }} onClick={() => setSelectedJob(null)}>
          <div style={{ backgroundColor: '#fff', padding: '30px', borderRadius: '16px', width: '600px', maxWidth: '90%', color: '#000', maxHeight: '90vh', overflowY: 'auto' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e2e8f0', paddingBottom: '15px', marginBottom: '20px' }}>
              <h2 style={{ margin: 0, fontSize: '20px' }}>💼 Munka Részletei</h2>
              <button onClick={() => setSelectedJob(null)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: '#64748b' }}>✕</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div><strong style={{ color: '#64748b', fontSize: '12px' }}>MEGNEVEZÉS</strong><div style={{ fontSize: '16px', fontWeight: 'bold' }}>{selectedJob.munka_nev}</div></div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                <div><strong style={{ color: '#64748b', fontSize: '12px' }}>KATEGÓRIA</strong><div>{selectedJob.kategoria}</div></div>
                <div><strong style={{ color: '#64748b', fontSize: '12px' }}>ÓRASZÁM</strong><div>{selectedJob.oraszam} óra</div></div>
              </div>
              <div><strong style={{ color: '#64748b', fontSize: '12px' }}>LEÍRÁS ÉS FELADATOK</strong><div style={{ fontSize: '14px', lineHeight: '1.6', whiteSpace: 'pre-wrap' }}>{selectedJob.leiras || 'Nincs leírás megadva.'}</div></div>
            </div>
            <div style={{ display: 'flex', gap: '10px', marginTop: '30px' }}>
              <button onClick={() => setSelectedJob(null)} style={{ flex: 1, padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0', background: '#fff', fontWeight: 'bold', cursor: 'pointer' }}>Bezárás</button>
              {(selectedJob.statusz === 'fuggoben' || !selectedJob.statusz) && (
                <button onClick={() => handleApproveJob(selectedJob)} style={{ flex: 1, padding: '12px', borderRadius: '8px', border: 'none', background: '#16a34a', color: '#fff', fontWeight: 'bold', cursor: 'pointer' }}>✓ Jóváhagyás</button>
              )}
              <button onClick={() => handleDeleteJob(selectedJob.munka_id, selectedJob.munka_nev, true)} style={{ flex: 1, padding: '12px', borderRadius: '8px', border: 'none', background: '#ef4444', color: '#fff', fontWeight: 'bold', cursor: 'pointer' }}>Törlés</button>
            </div>
          </div>
        </div>
      )}

      {selectedCompany && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0,0,0,0.6)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 3000, backdropFilter: 'blur(4px)' }} onClick={() => setSelectedCompany(null)}>
          <div style={{ backgroundColor: '#fff', padding: '30px', borderRadius: '16px', width: '500px', maxWidth: '95%', color: '#000' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2 style={{ margin: 0 }}>🏢 Cég Adatlap</h2>
              <button onClick={() => setSelectedCompany(null)} style={{ background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer' }}>✕</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
              <p><strong>Név:</strong> {selectedCompany.cegnev}</p>
              <p><strong>Email:</strong> {selectedCompany.ceg_email}</p>
              <p><strong>Adószám:</strong> {selectedCompany.adoszam}</p>
              <p><strong>Cím:</strong> {selectedCompany.cim}</p>
              <p><strong>Telefonszám:</strong> {selectedCompany.telefonszam || '-'}</p>
            </div>
            <button onClick={() => setSelectedCompany(null)} className="admin-logout-btn" style={{ marginTop: '20px', width: '100%' }}>Bezárás</button>
          </div>
        </div>
      )}

      {selectedStudent && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0,0,0,0.6)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 3000, backdropFilter: 'blur(4px)' }} onClick={() => setSelectedStudent(null)}>
          <div style={{ backgroundColor: '#fff', padding: '30px', borderRadius: '16px', width: '500px', maxWidth: '95%', color: '#000' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2 style={{ margin: 0 }}>🎓 Diák Adatlap</h2>
              <button onClick={() => setSelectedStudent(null)} style={{ background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer' }}>✕</button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
              <p><strong>Név:</strong> {selectedStudent.nev}</p>
              <p><strong>Email:</strong> {selectedStudent.email}</p>
              <p><strong>Iskola:</strong> {selectedStudent.iskola || '-'}</p>
              <p><strong>Ledolgozott órák:</strong> {selectedStudent.ledolgozott_ora || 0} óra</p>
            </div>
            <button onClick={() => setSelectedStudent(null)} className="admin-logout-btn" style={{ marginTop: '20px', width: '100%' }}>Bezárás</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;