import { useState, useEffect } from "react";
import axios from "axios";
import { useToast } from "../Other/ToastContext";
import "./Login.css";

const API_URL = "https://localhost:7259/api";

export default function Login() {
  const [userType, setUserType] = useState("diak");
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: "", password: "", fullName: "", phone: "", school: "", companyName: "", taxNumber: "", address: ""
  });

  const toast = useToast();


  useEffect(() => {
    const isDark = localStorage.getItem('theme') === 'dark';
    if (isDark) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  }, []);

  const formatTaxNumber = (val) => {
    const nums = val.replace(/\D/g, "");
    const trimmed = nums.substring(0, 11);
    if (trimmed.length <= 8) return trimmed;
    if (trimmed.length <= 9) return `${trimmed.slice(0, 8)}-${trimmed.slice(8)}`;
    return `${trimmed.slice(0, 8)}-${trimmed.slice(8, 9)}-${trimmed.slice(9, 11)}`;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let finalValue = value;
    if (name === "phone") finalValue = value.replace(/\D/g, "").slice(0, 12);
    else if (name === "taxNumber") finalValue = formatTaxNumber(value);

    setFormData(prev => ({ ...prev, [name]: finalValue }));
  };

  const goToLandingPage = () => window.location.href = "/";

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isLogin) {
        const response = await axios.post(`${API_URL}/Auth/login`, {
          email: formData.email, jelszo: formData.password,
        });

        const kapottTipus = response.data.userType;
        if (!kapottTipus) {
          toast.error("Hiba: A szerver nem küldte el a jogosultságot!");
          return;
        }

        localStorage.setItem("token", response.data.token);
        localStorage.setItem("userType", kapottTipus);

        const userId = kapottTipus === "diak" ? response.data.diakId : response.data.ceg_id;
        if (userId) localStorage.setItem("userId", userId);

        const userNameToSave = response.data.nev || response.data.cegnev || formData.email.split('@')[0];
        localStorage.setItem("userName", userNameToSave);

        window.location.href = "/";
      } else {
        const endpoint = userType === "diak" ? "Diak" : "Ceg";
        const payload = userType === "diak"
          ? { nev: formData.fullName, email: formData.email, jelszo: formData.password, iskola: formData.school, telefonszam: formData.phone }
          : { cegnev: formData.companyName, ceg_email: formData.email, cim: formData.address, adoszam: formData.taxNumber, telefonszam: formData.phone, jelszo: formData.password };

        await axios.post(`${API_URL}/${endpoint}`, payload);

        toast.success("Sikeres regisztráció! Kérlek, jelentkezz be.");

        const registeredName = userType === "diak" ? formData.fullName : formData.companyName;
        localStorage.setItem("userName", registeredName);

        setIsLogin(true);
      }
    } catch (error) {
      console.error("Szerver hiba:", error.response?.data);
      const errorMsg = error.response?.data?.message || error.response?.data || "Hiba a szerverrel!";

      if (error.response?.data?.messages) {
        toast.error(error.response.data.messages.join("\n"));
      } else {
        toast.error(errorMsg);
      }
    }
  };

  return (
    <main className="login-page">
      <section className="login-card">
        <div className="login-header-fixed">
          <header className="brand" onClick={goToLandingPage} style={{ cursor: "pointer" }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
            </svg>
            <h1>Ötven Óra</h1>
          </header>

          <nav className="auth-toggle">
            <button className={isLogin ? "active" : ""} onClick={() => setIsLogin(true)}>Bejelentkezés</button>
            <button className={!isLogin ? "active" : ""} onClick={() => setIsLogin(false)}>Regisztráció</button>
          </nav>

          <h2>{isLogin ? "Üdvözlünk újra!" : "Hozd létre a fiókod"}</h2>

          <p className="description">
            {isLogin ? "Csatlakozz a közösséghez és gyűjtsd az óráidat." : (userType === "diak" ? "Csatlakozz a közösséghez és gyűjtsd az óráidat." : "Közvetítsd az aktív munkákat, könnyen és gyorsan.")}
          </p>

          {!isLogin && (
            <div className="user-type-toggle">
              <button type="button" className={userType === "diak" ? "type-btn active" : "type-btn"} onClick={() => setUserType("diak")}>
                Regisztrálás Diákként
              </button>
              <button type="button" className={userType === "ceg" ? "type-btn active" : "type-btn"} onClick={() => setUserType("ceg")}>
                Regisztrálás Cégként
              </button>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="login-form-scrollable">
          {!isLogin && userType === "diak" && (
            <>
              <Field label="Teljes név" name="fullName" placeholder="Példa Péter" value={formData.fullName} onChange={handleChange} required={true} />
              <Field label="Telefonszám (opcionális)" name="phone" placeholder="06304568423" value={formData.phone} onChange={handleChange} required={false} />
              <Field label="Iskola (opcionális)" name="school" placeholder="Az Élet Iskolája" value={formData.school} onChange={handleChange} required={false} />
            </>
          )}

          {!isLogin && userType === "ceg" && (
            <>
              <Field label="Cégnév" name="companyName" placeholder="Példa Kft." value={formData.companyName} onChange={handleChange} required={true} />
              <Field label="Adószám" name="taxNumber" placeholder="12345678-1-11" value={formData.taxNumber} onChange={handleChange} required={true} />
              <Field label="Székhely" name="address" placeholder="Budapest, Fő utca 1." value={formData.address} onChange={handleChange} required={true} />
              <Field label="Telefonszám" name="phone" placeholder="06304568423" value={formData.phone} onChange={handleChange} required={true} />
            </>
          )}

          <Field label="E-mail" name="email" type="email" placeholder="pelda@gmail.com" value={formData.email} onChange={handleChange} required={true} />
          <Field label="Jelszó" name="password" type="password" value={formData.password} onChange={handleChange} required={true} showCriteria={!isLogin} />

          <button className="submit-btn">{isLogin ? "Belépés →" : "Regisztráció →"}</button>
        </form>

        <div className="login-footer-fixed">
          <div className="separator"><span>Vagy</span></div>
          <div className="social-grid">
            <button type="button" className="social-item"><svg width="20px" height="auto" viewBox="-3 0 262 262" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid"><path d="M255.878 133.451c0-10.734-.871-18.567-2.756-26.69H130.55v48.448h71.947c-1.45 12.04-9.283 30.172-26.69 42.356l-.244 1.622 38.755 30.023 2.685.268c24.659-22.774 38.875-56.282 38.875-96.027" fill="#4285F4"/><path d="M130.55 261.1c35.248 0 64.839-11.605 86.453-31.622l-41.196-31.913c-11.024 7.688-25.82 13.055-45.257 13.055-34.523 0-63.824-22.773-74.269-54.25l-1.531.13-40.298 31.187-.527 1.465C35.393 231.798 79.49 261.1 130.55 261.1" fill="#34A853"/><path d="M56.281 156.37c-2.756-8.123-4.351-16.827-4.351-25.82 0-8.994 1.595-17.697 4.206-25.82l-.073-1.73L15.26 71.312l-1.335.635C5.077 89.644 0 109.517 0 130.55s5.077 40.905 13.925 58.602l42.356-32.782" fill="#FBBC05"/><path d="M130.55 50.479c24.514 0 41.05 10.589 50.479 19.438l36.844-35.974C195.245 12.91 165.798 0 130.55 0 79.49 0 35.393 29.301 13.925 71.947l42.211 32.783c10.59-31.477 39.891-54.251 74.414-54.251" fill="#EB4335"/></svg>Google</button>
            <button type="button" className="social-item"><svg width="20px" height="auto" viewBox="126.445 2.281 589 589" xmlns="http://www.w3.org/2000/svg"><circle cx="420.945" cy="296.781" r="294.5" fill="#3c5a9a"/><path d="M516.704 92.677h-65.239c-38.715 0-81.777 16.283-81.777 72.402.189 19.554 0 38.281 0 59.357H324.9v71.271h46.174v205.177h84.847V294.353h56.002l5.067-70.117h-62.531s.14-31.191 0-40.249c0-22.177 23.076-20.907 24.464-20.907 10.981 0 32.332.032 37.813 0V92.677h-.032z" fill="#ffffff"/></svg>Facebook</button>
          </div>
          <p className="bottom-text">
            {isLogin ? "Nincs még fiókod?" : "Már van fiókod?"}
            <button type="button" onClick={() => setIsLogin(!isLogin)}>
              {isLogin ? "Regisztrálj ingyen" : "Jelentkezz be"}
            </button>
          </p>
        </div>
      </section>

      <aside className="login-visual">
        <div className="visual-content">
          <span className="tag">1,500+ önkéntes</span>
          <h2>Építsünk együtt egy jobb jövőt.</h2>
        </div>
      </aside>
    </main>
  );
}

const Field = ({ label, name, value, required, type, showCriteria, ...props }) => {
  const isEmpty = !value || value.trim() === "";
  const isPassword = type === "password";
  const criteria = [
    { label: "Legalább 8 karakter", met: value.length >= 8 },
    { label: "Kis- és nagybetű", met: /[a-z]/.test(value) && /[A-Z]/.test(value) },
    { label: "Legalább egy szám", met: /\d/.test(value) },
    { label: "Speciális karakter (@#$!%*?&_-)", met: /[!@#$%^&*(),.?":{}|<>_-]/.test(value) }
  ];

  const isAllCriteriaMet = criteria.every(c => c.met);
  const isEmail = type === "email";
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isValidEmail = emailRegex.test(value);
  const isTaxNumber = name === "taxNumber";
  const taxRegex = /^\d{8}-\d{1}-\d{2}$/;
  const isValidTax = taxRegex.test(value);

  let dotColor = "var(--border-color)";

  if (required) {
    if (isPassword) {
      if (showCriteria) dotColor = !isEmpty && isAllCriteriaMet ? "#10b981" : "#ef4444";
      else dotColor = isEmpty ? "var(--border-color)" : "#10b981";
    } else if (isEmail) dotColor = !isEmpty && isValidEmail ? "#10b981" : "#ef4444";
    else if (isTaxNumber) dotColor = !isEmpty && isValidTax ? "#10b981" : "#ef4444";
    else dotColor = !isEmpty ? "#10b981" : "#ef4444";
  } else {
    dotColor = isEmpty ? "var(--border-color)" : "#10b981";
  }

  return (
    <div className="input-field" style={{ marginBottom: "15px" }}>
      <label style={{ display: "flex", alignItems: "center", gap: "5px", marginBottom: "5px", color: "var(--text-main)" }}>
        {label}
        {(!isPassword || showCriteria) && (
          <span style={{ width: "8px", height: "8px", borderRadius: "50%", backgroundColor: dotColor, display: "inline-block", transition: "all 0.3s ease" }} />
        )}
      </label>

      <input name={name} value={value} type={type} required={required} {...props} />

      {isPassword && showCriteria && !isAllCriteriaMet && (
        <div style={{ marginTop: "8px", fontSize: "11px", color: "var(--text-muted)" }}>
          <p style={{ margin: "0 0 5px 0", fontWeight: "bold" }}>Hiányzó feltételek:</p>
          <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {criteria.map((c, index) => (
              !c.met && <li key={index} style={{ color: "#ef4444" }}>• {c.label}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};