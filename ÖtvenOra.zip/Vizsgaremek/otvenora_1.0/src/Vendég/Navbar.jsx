import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [darkMode, setDarkMode] = useState(localStorage.getItem('theme') === 'dark');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);


  useEffect(() => {
    const token = localStorage.getItem('token');
    const name = localStorage.getItem('userName');

    if (token) {
      setIsLoggedIn(true);
      setUserName(name || 'Profilom');
    }

    if (darkMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  }, [darkMode]);

  const handleLogout = () => {
    localStorage.clear();
    setIsLoggedIn(false);
    navigate('/');
    setIsMobileMenuOpen(false);
  };

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('theme', newMode ? 'dark' : 'light');
    if (newMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  };

  const handleNavClick = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };


  return (
    <nav className="lp-navbar">
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        <div className="lp-logo" onClick={() => handleNavClick('/')}>
          <span className="logo-icon">🎓</span>
          <span className="logo-text">Ötven óra</span>
        </div>

        <button
          onClick={toggleDarkMode}
          className="guest-theme-toggle"
          title={darkMode ? "Világos mód bekapcsolása" : "Sötét mód bekapcsolása"}
        >
          {darkMode ? '☀️' : '🌙'}
        </button>
      </div>

      <button
        className="navbar-hamburger"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        style={{ color: 'var(--text-main)' }}
      >
        {isMobileMenuOpen ? (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        ) : (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        )}
      </button>

      <div className={`lp-right-section ${isMobileMenuOpen ? 'open' : ''}`}>

        <div className="lp-nav-links">
          <span onClick={() => handleNavClick('/munkak')}>Munkák</span>
          <span onClick={() => handleNavClick('/cegeknek')}>Cégeknek</span>
          <span onClick={() => handleNavClick('/rolunk')}>Rólunk</span>
          <span onClick={() => handleNavClick('/segitseg')}>Segítség</span>

          {!isLoggedIn && (
            <span className="guest-badge">Vendég</span>
          )}
        </div>

        <div className="lp-auth-buttons">
          {isLoggedIn ? (
            <>
              <button className="auth-btn-logged auth-profile" onClick={() => handleNavClick('/profil')}>
                👤 {userName}
              </button>
              <button className="auth-btn-logged auth-logout" onClick={handleLogout}>
                Kijelentkezés
              </button>
            </>
          ) : (
            <>
              <button className="animated-auth-btn login-btn" onClick={() => handleNavClick('/login')}>
                <div className="btn-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </div>
                <span className="btn-text">Bejelentkezés</span>
              </button>

              <button className="animated-auth-btn register-btn" onClick={() => handleNavClick('/login')}>
                <div className="btn-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 5v14M5 12h14" />
                  </svg>
                </div>
                <span className="btn-text">Regisztráció</span>
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}