import axios from 'axios';

const api = axios.create({
    baseURL: 'https://localhost:7259/api', // Ellenőrizd a portot a Swaggerben!
    headers: {
        'Content-Type': 'application/json'
    }
});

export default api;