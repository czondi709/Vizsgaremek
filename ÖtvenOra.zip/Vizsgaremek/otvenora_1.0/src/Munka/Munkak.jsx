import React, { useState, useEffect } from 'react';
import Navbar from '../Vendég/Navbar';
import { useNavigate } from 'react-router-dom';
import NavbarStudent from '../Diák/NavbarStudent';
import axios from 'axios';
import './Munkak.css';

const Munkak = () => {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  const [searchTerm, setSearchTerm] = useState('');
  const [hoursRange, setHoursRange] = useState([1, 50]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [locationSearch, setLocationSearch] = useState('');

  const getDefaultImage = (category, title) => {
    const cat = category ? category.toLowerCase().trim() : '';
    const name = title ? title.toLowerCase().trim() : '';

    if (cat.includes('állat') || name.includes('kutya') || name.includes('menhely')) return 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?q=80&w=800&auto=format&fit=crop';
    if (cat.includes('sport') || name.includes('verseny') || name.includes('foci') || name.includes('meccs')) return 'https://images.pexels.com/photos/10475536/pexels-photo-10475536.jpeg';
    if (cat.includes('környezet') || name.includes('takarítás') || name.includes('park') || name.includes('szemét')) return 'https://images.pexels.com/photos/7538360/pexels-photo-7538360.jpeg';
    if (cat.includes('szociális') || cat.includes('idős') || name.includes('segítség')) return 'https://media.istockphoto.com/id/1444971252/hu/fot%C3%B3/gondnok-id%C5%91s-f%C3%A9rfival-aki-k%C3%A1v%C3%A9sz%C3%BCnetet-%C3%A9lvez.jpg?s=1024x1024&w=is&k=20&c=rjfu_PZhQHZcalZfEGbe0qTk5ofSbixaEgOM5dOWlyw=';
    if (cat.includes('kultur') || cat.includes('közművel') || name.includes('könyv') || name.includes('múzeum')) return 'https://images.pexels.com/photos/17010584/pexels-photo-17010584.jpeg';
    if (cat.includes('oktatás') || name.includes('tanítás') || name.includes('gyerek')) return 'https://images.pexels.com/photos/3401403/pexels-photo-3401403.jpeg';
    if (cat.includes('egészség')) return 'https://media.istockphoto.com/id/2207018387/hu/fot%C3%B3/%C3%B6nk%C3%A9ntes-s%C3%A9ta-a-kertben-id%%C5%91s-n%C5%91vel-az-id%C5%91sek-otthon%C3%A1ban.jpg?s=1024x1024&w=is&k=20&c=3TgwU4e3Da_hlErVERv8PKQSPBOCTZbIUn5qjJOievE=';
    return 'https://images.pexels.com/photos/31874011/pexels-photo-31874011.jpeg';
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
      setUserType(localStorage.getItem('userType'));
    }

    const fetchJobs = async () => {
      try {
        const response = await axios.get('https://localhost:7259/api/Munka', {
          headers: token ? { Authorization: `Bearer ${token}` } : {}
        });
        if (response.data) {
          const aktivMunkak = response.data.filter(m => m.statusz === 'aktiv' || m.statusz === 'aktív');
          setJobs(aktivMunkak.reverse());
        }
      } catch (error) {
        console.error("Hiba a munkák lekérésekor:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchJobs();
  }, []);

  const handleDetails = (jobId) => navigate(`/munka-reszletek/${jobId}`);

  const handleCategoryChange = (category) => {
    setSelectedCategories(prev => prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setHoursRange([1, 50]);
    setSelectedCategories([]);
    setLocationSearch('');
  };

  const filteredJobs = jobs.filter((job) => {
    const lowerSearch = searchTerm.toLowerCase();
    const safeTitle = job.munka_nev ? job.munka_nev.toLowerCase() : '';
    const safeCompany = (job.ceg?.cegnev || job.ceg?.Cegnev || 'Közösségi Partner').toLowerCase();
    const safeDesc = job.leiras ? job.leiras.toLowerCase() : '';
    const safeLoc = job.cim ? job.cim.toLowerCase() : '';
    const safeCat = job.kategoria ? job.kategoria.toLowerCase() : '';

    const matchSearch = searchTerm === '' || safeTitle.includes(lowerSearch) || safeCompany.includes(lowerSearch) || safeDesc.includes(lowerSearch);
    const matchHours = job.oraszam >= hoursRange[0] && job.oraszam <= hoursRange[1];
    const matchCategory = selectedCategories.length === 0 || selectedCategories.includes(safeCat);
    const matchLocation = locationSearch === '' || safeLoc.includes(locationSearch.toLowerCase());

    return matchSearch && matchHours && matchCategory && matchLocation;
  });

  return (
    <div className="munkak-page-container">
      {isLoggedIn && userType === 'diak' ? <NavbarStudent /> : <Navbar />}

      <div className="munkak-layout-wrapper">
        <aside className="munkak-sidebar">
          <header className="sidebar-header">
            <span className="filter-icon">🌐</span>
            <h2 style={{ color: 'var(--text-main)' }}>Szűrők</h2>
          </header>

          <section className="filter-section">
            <label>Kategóriák</label>
            <div className="category-checkboxes">
              {["környezetvédelem", "állatvédelem", "szociális", "idősgondozás", "kulturális", "közművelődés", "oktatás", "sport", "egészségügyi", "katasztrófavédelem"].map(cat => (
                <label key={cat} className="checkbox-label">
                  <input type="checkbox" checked={selectedCategories.includes(cat)} onChange={() => handleCategoryChange(cat)} />
                  <span>{cat.charAt(0).toUpperCase() + cat.slice(1)}</span>
                </label>
              ))}
            </div>
          </section>

          <section className="filter-section">
            <label>ÓRASZÁM</label>
            <div className="hours-range-display" style={{ color: 'var(--primary-color)' }}>
              {hoursRange[0]} - {hoursRange[1]} óra
            </div>
            <input type="range" min="1" max="50" value={hoursRange[1]} className="hours-slider" onChange={(e) => setHoursRange([1, parseInt(e.target.value)])} />
          </section>

          <section className="filter-section">
            <label htmlFor="location">HELYSZÍN</label>
            <div className="location-input-wrapper">
              <span className="location-pin-icon">📍</span>
              <input id="location" type="text" placeholder="Város..." className="sidebar-input" value={locationSearch} onChange={(e) => setLocationSearch(e.target.value)} />
            </div>
            <div className="quick-locations">
              <button className="location-tag-btn" onClick={() => setLocationSearch('Budapest')}>Budapest</button>
              <button className="location-tag-btn" onClick={() => setLocationSearch('Debrecen')}>Debrecen</button>
            </div>
          </section>
        </aside>

        <main className="munkak-main-content">
          <header className="main-content-header">
            <div>
              <h1 className="page-title" style={{ color: 'var(--text-main)' }}>Elérhető lehetőségek</h1>
              <p className="page-subtitle" style={{ color: 'var(--text-muted)' }}>Találd meg a számodra legmegfelelőbb munkát és gyűjtsd az órákat.</p>
            </div>
          </header>

          <div className="active-filters-tags">
            <button className={`filter-tag-btn active`} onClick={clearFilters}>Minden</button>
            {locationSearch && <button className="filter-tag-btn removable" onClick={() => setLocationSearch('')}>{locationSearch} ✕</button>}
            {selectedCategories.map(cat => (
              <button key={cat} className="filter-tag-btn removable" onClick={() => handleCategoryChange(cat)}>{cat.charAt(0).toUpperCase() + cat.slice(1)} ✕</button>
            ))}
            {(selectedCategories.length > 0 || locationSearch || searchTerm !== '' || hoursRange[1] < 50) && (
              <button className="filter-tag-btn text-link" onClick={clearFilters}>Szűrők törlése</button>
            )}

          </div>

          <div className="munkak-grid">
            {loading ? (
              <div className="no-results-message">Munkák betöltése... ⏳</div>
            ) : filteredJobs.length > 0 ? (
              filteredJobs.map(job => (
                <div key={job.munka_id} className="munka-card-animation-wrapper">
                  <div className="munka-card">
                    <div className="card-image-wrapper">
                      <img src={job.kepUrl || getDefaultImage(job.kategoria, job.munka_nev)} alt={job.munka_nev} className="card-image" />
                      <div className="card-badge card-badge-hours">⏱️ {job.oraszam} óra</div>
                      {job.oraszam > 20 && <div className="card-badge card-badge-status">Hosszútávú</div>}
                    </div>
                    <div className="card-content">
                      <span className="munka-category-badge">{job.kategoria || 'Általános'}</span>
                      <h3 className="munka-title" style={{ color: 'var(--text-main)' }}>{job.munka_nev}</h3>
                      <p className="munka-company" style={{ color: 'var(--text-muted)' }}>{job.ceg?.cegnev || job.ceg?.Cegnev || 'Közösségi Partner'}</p>
                      <p className="munka-description" style={{ color: 'var(--text-muted)' }}>{job.leiras}</p>
                      <div className="card-footer" style={{ borderTopColor: 'var(--border-color)' }}>
                        <span className="card-location" style={{ color: 'var(--text-muted)' }}>📍 {job.cim}</span>
                        <button onClick={() => handleDetails(job.munka_id)} className="card-apply-btn">Részletek</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="no-results-message">Nincs a keresésnek megfelelő munka.</div>
            )}
          </div>

          {filteredJobs.length > 0 && (
            <div className="load-more-section">
              <button className="load-more-btn">További lehetőségek betöltése ▼</button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Munkak;