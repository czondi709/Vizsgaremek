import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import DynamicNavbar from '../Other/DynamicNavbar';
import { useToast } from '../Other/ToastContext';
import './UjHirdetes.css';

export default function UjHirdetes() {
  const navigate = useNavigate();
  const toast = useToast();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const isDark = localStorage.getItem('theme') === 'dark';
    if (isDark) document.body.classList.add('dark-theme');
    else document.body.classList.remove('dark-theme');
  }, []);

  const categories = [
    { id: 'környezetvédelem', label: 'Környezetvédelem', icon: '🌳' },
    { id: 'állatvédelem', label: 'Állatvédelem', icon: '🐾' },
    { id: 'szociális', label: 'Szociális', icon: '🤝' },
    { id: 'idősgondozás', label: 'Idősgondozás', icon: '👵' },
    { id: 'kulturális', label: 'Kulturális', icon: '🏛️' },
    { id: 'közművelődés', label: 'Közművelődés', icon: '🎭' },
    { id: 'oktatás', label: 'Oktatás', icon: '🎓' },
    { id: 'sport', label: 'Sport', icon: '⚽' },
    { id: 'egészségügyi', label: 'Egészségügyi', icon: '🏥' },
    { id: 'katasztrófavédelem', label: 'Katasztrófavédelem', icon: '🚒' }
  ];

  const [jobData, setJobData] = useState({
    munka_nev: '',
    cim: '',
    idopont: '',
    letszam: '',
    oraszam: '',
    kategoria: 'környezetvédelem',
    leiras: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setJobData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const ceg_id = localStorage.getItem('userId');
    const token = localStorage.getItem('token');

    if (!ceg_id) {
      toast.error("Hiba: Nem található céges azonosító! Kérlek lépj be újra.");
      setLoading(false);
      return;
    }

    try {
      await axios.post('https://localhost:7259/api/Munka', {
        munka_nev: jobData.munka_nev,
        cim: jobData.cim,
        idopont: jobData.idopont,
        oraszam: parseInt(jobData.oraszam),
        letszam: parseInt(jobData.letszam),
        leiras: jobData.leiras,
        kategoria: jobData.kategoria,
        ceg_id: parseInt(ceg_id),
        statusz: "aktiv"
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success("Munka meghirdetve!");
      navigate('/ceg-profil');
    } catch (error) {
      console.error("Hiba a hirdetés feladásakor:", error);
      toast.error("Sikertelen feladás. Ellenőrizd az adatokat!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="new-job-page">
      <DynamicNavbar />

      <div className="new-job-container">

        <div className="new-job-header anim-fade-in">
          <button type="button" className="btn-secondary back-btn" onClick={() => navigate('/ceg-profil')}>
            ← Vissza
          </button>
          <div>
            <div className="breadcrumbs">Portál / <strong>Új Hirdetés</strong></div>
            <h1 className="page-title">Új munka meghirdetése</h1>
          </div>
        </div>

        <div className="new-job-card anim-fade-in-delayed">
          <form onSubmit={handleSubmit} className="new-job-form">

            <div className="input-group">
              <label>Pozíció megnevezése *</label>
              <input
                type="text" name="munka_nev" required
                value={jobData.munka_nev} onChange={handleInputChange}
                placeholder="pl. Szemétszedés a parkban, Idősek segítése..."
              />
            </div>

            <div className="input-group">
              <label>Munkavégzés helyszíne (Cím) *</label>
              <div className="input-with-icon">
                <span>📍</span>
                <input
                  type="text" name="cim" required
                  value={jobData.cim} onChange={handleInputChange}
                  placeholder="Város, utca, házszám"
                />
              </div>
            </div>

            <div className="form-row three-cols">
              <div className="input-group">
                <label>Munka kezdésének időpontja *</label>
                <div className="input-with-icon">
                  <span>📅</span>
                  <input
                    type="datetime-local" name="idopont" required
                    value={jobData.idopont} onChange={handleInputChange}
                  />
                </div>
              </div>

              <div className="input-group">
                <label>Létszám (fő) *</label>
                <input
                  type="number" name="letszam" required min="1"
                  value={jobData.letszam} onChange={handleInputChange}
                  placeholder="pl. 4"
                />
              </div>

              <div className="input-group">
                <label>Max. Óraszám (fő)*</label>
                <input
                  type="number" name="oraszam" required min="1" max="50"
                  value={jobData.oraszam} onChange={handleInputChange}
                  placeholder="pl. 7"
                />
              </div>
            </div>

            <div className="input-group">
              <label>Kategória (Válassz egyet) *</label>
              <div className="radio-group-container">
                {categories.map(cat => (
                  <label key={cat.id} className={`radio-card ${jobData.kategoria === cat.id ? 'selected' : ''}`}>
                    <input
                      type="radio"
                      name="kategoria"
                      value={cat.id}
                      checked={jobData.kategoria === cat.id}
                      onChange={handleInputChange}
                    />
                    <span className="radio-icon">{cat.icon}</span>
                    <span className="radio-text">{cat.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="input-group">
              <label>Részletes leírás a feladatokról és elvárások ismertetése*</label>
              <textarea
                rows="6" name="leiras" required
                value={jobData.leiras} onChange={handleInputChange}
                placeholder="Írd le, mi lesz a diákok pontos feladata..."
              ></textarea>
            </div>

            <div className="form-actions">
              <button type="button" className="btn-secondary" onClick={() => navigate('/ceg-profil')}>Mégsem</button>
              <button type="submit" className="btn-primary" disabled={loading}>
                {loading ? '⏳ Feltöltés...' : '📢 Hirdetés Élesítése'}
              </button>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
}