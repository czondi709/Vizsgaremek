import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import DynamicNavbar from '../Other/DynamicNavbar';
import { useToast } from '../Other/ToastContext';
import './JobDetails.css';

export default function JobDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [job, setJob] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [similarJobs, setSimilarJobs] = useState([]);
  const [spotsLeft, setSpotsLeft] = useState(0);

  const [applicationStatus, setApplicationStatus] = useState("elküldve");
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [applyLoading, setApplyLoading] = useState(false);

  const [isSaved, setIsSaved] = useState(false);

  const [showShareModal, setShowShareModal] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setLoading(true);
    setJob(null);
    setSimilarJobs([]);

    const fetchJobDetails = async () => {
      try {
        const munkaRes = await axios.get('https://localhost:7259/api/Munka');
        const foundJob = munkaRes.data.find(m => String(m.munka_id) === String(id));

        if (foundJob) {
          setJob(foundJob);

          try {
            const jelentkezesRes = await axios.get(`https://localhost:7259/api/Jelentkezes/munka/${id}`);
            const jelentkezokSzama = jelentkezesRes.data.length || 0;
            setSpotsLeft(Math.max(0, foundJob.letszam - jelentkezokSzama));
          } catch (jelErr) {
            setSpotsLeft(foundJob.letszam);
          }

          const similar = munkaRes.data.filter(m => {
            if (!m || !m.statusz) return false;
            const isSameCategory = m.kategoria === foundJob.kategoria;
            const isNotCurrentId = String(m.munka_id) !== String(id);
            const isNotSameName = m.munka_nev.trim().toLowerCase() !== foundJob.munka_nev.trim().toLowerCase();
            const isActive = m.statusz.toLowerCase() === 'aktiv' || m.statusz.toLowerCase() === 'aktív';
            return isSameCategory && isNotCurrentId && isNotSameName && isActive;
          });

          const topSimilar = similar.sort((a, b) => b.munka_id - a.munka_id).slice(0, 3);
          setSimilarJobs(topSimilar);

          try {
            const cegRes = await axios.get(`https://localhost:7259/api/Ceg/${foundJob.ceg_id}`);
            setCompany(cegRes.data);
          } catch (cegErr) {
            console.error("Nem sikerült lekérni a céget", cegErr);
          }
        }
      } catch (error) {
        console.error("Hiba a munka lekérésekor:", error);
        toast.error("Hiba a munka adatlápjának betöltésekor!");
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();

    const userId = localStorage.getItem('userId');
    if (userId) {
      const savedJobs = JSON.parse(localStorage.getItem(`savedJobs_${userId}`) || '[]');
      if (savedJobs.includes(id)) {
        setIsSaved(true);
      }
    }
  }, [id]);

  const formatDateTime = (dateString) => {
    if (!dateString) return { date: '', time: '' };
    const d = new Date(dateString);
    const date = d.toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric' });
    const time = d.toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });
    const dayName = d.toLocaleDateString('hu-HU', { weekday: 'long' });
    return { date, time, dayName };
  };

  const handleApply = async () => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');

    if (!token || !userId) {
      setShowAuthModal(true);
      return;
    }

    setApplyLoading(true);
    try {
      const now = new Date();
      const tzOffset = now.getTimezoneOffset() * 60000;
      const localISOTime = (new Date(now - tzOffset)).toISOString().slice(0, 19);

      await axios.post('https://localhost:7259/api/Jelentkezes', {
        munka_id: parseInt(id),
        diak_id: parseInt(userId),
        jelentkezes_ideje: localISOTime,
        munka_statusz: applicationStatus
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setShowSuccessModal(true);
      setSpotsLeft(prev => Math.max(0, prev - 1));

    } catch (error) {
      setShowErrorModal(true);
    } finally {
      setApplyLoading(false);
    }
  };

  const handleSaveToggle = () => {
    const userId = localStorage.getItem('userId');
    if (!userId) {
      setShowAuthModal(true);
      return;
    }

    let savedJobs = JSON.parse(localStorage.getItem(`savedJobs_${userId}`) || '[]');

    if (isSaved) {
      savedJobs = savedJobs.filter(jobId => jobId !== id);
      setIsSaved(false);
      toast.info("Munka eltávolítva a mentettek közül.");
    } else {
      savedJobs.push(id);
      setIsSaved(true);
      toast.success("A hirdetés bekerült a mentett munkáid közé!");
    }

    localStorage.setItem(`savedJobs_${userId}`, JSON.stringify(savedJobs));
  };

  const handleCopyLink = () => {
    const currentUrl = window.location.href;
    navigator.clipboard.writeText(currentUrl).then(() => {
      setShowShareModal(false);
      toast.success("A hirdetés linkje a vágólapra került!");
    });
  };

  if (loading) {
    return (
      <div className="job-details-page">
        <DynamicNavbar />
        <div style={{ textAlign: 'center', padding: '100px', fontSize: '20px', color: 'var(--text-muted)' }}>⏳ Betöltés...</div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="job-details-page">
        <DynamicNavbar />
        <div style={{ textAlign: 'center', padding: '100px', fontSize: '20px', color: 'var(--text-muted)' }}>❌ A munka nem található!</div>
      </div>
    );
  }

  const { date, time, dayName } = formatDateTime(job.idopont);

  return (
    <div className="job-details-page">
      <DynamicNavbar />

      <div className="jd-container">

        <div className="job-anim-wrapper jd-breadcrumb-section" style={{ animationDelay: '0.1s' }}>
          <div className="jd-breadcrumbs">
            <span onClick={() => navigate('/')}>Kezdőlap</span> &gt; <span onClick={() => navigate('/munkak')}>Munkák</span> &gt; <strong>{job.munka_nev}</strong>
          </div>
        </div>

        <div className="jd-layout">

          <div className="jd-left-column">
            <div className="job-anim-wrapper" style={{ animationDelay: '0.2s' }}>
              <div className="jd-header-card job-hover-card">
                <div className="jd-badges">
                  <span className="jd-badge category-badge">{job.kategoria || 'ÁLTALÁNOS'}</span>
                </div>
                <h1 className="jd-main-title">{job.munka_nev}</h1>

                <div className="jd-company-card job-hover-card">
                  <div className="jd-company-avatar">
                    {company?.cegnev ? company.cegnev.charAt(0).toUpperCase() : '🏢'}
                  </div>
                  <div className="jd-company-info">
                    <h3>{company?.cegnev || 'Közösségi Partner'}</h3>
                    <p>{company?.cim || 'Cím nem elérhető'}</p>
                  </div>

                </div>
              </div>
            </div>

            <div className="job-anim-wrapper" style={{ animationDelay: '0.3s' }}>
              <div className="jd-content-card job-hover-card">
                <h2 className="jd-card-title">📄 A feladat és az elvárások ismertetése</h2>
                <div className="jd-description-text">
                  {job.leiras.split('\n').map((line, i) => (
                    <p key={i}>{line}</p>
                  ))}
                </div>


              </div>
            </div>
          </div>

          <div className="jd-right-column">

            <div className="job-anim-wrapper" style={{ animationDelay: '0.4s' }}>
              <div className="jd-card jd-reward-card job-hover-card">
                <p className="jd-reward-subtitle">Jutalmazás / Legtöbb kapható óraszám</p>
                <h2 className="jd-reward-title">⏳ {job.oraszam} óra <span>igazolt közösségi szolgálat</span></h2>

                <button
                  className="jd-apply-btn"
                  onClick={handleApply}
                  disabled={applyLoading || spotsLeft === 0}
                >
                  {applyLoading ? '⏳ Jelentkezés...' : (spotsLeft === 0 ? 'Megtelt' : 'Jelentkezés →')}
                </button>

                <div className="jd-action-buttons">
                  <button
                    className={`jd-action-btn ${isSaved ? 'saved' : ''}`}
                    onClick={handleSaveToggle}
                  >
                    {isSaved ? '★ Mentve' : '☆ Mentés'}
                  </button>
                  <button className="jd-action-btn" onClick={() => setShowShareModal(true)}>Megosztás</button>
                </div>
              </div>
            </div>

            <div className="job-anim-wrapper" style={{ animationDelay: '0.5s' }}>
              <div className="jd-card jd-info-card job-hover-card">
                <div className="jd-info-row">
                  <div className="jd-info-icon">📅</div>
                  <div className="jd-info-content">
                    <h4>Időpont</h4>
                    <p>{date}</p>
                    <span className="jd-sub-info">{dayName.charAt(0).toUpperCase() + dayName.slice(1)}, {time}-kor</span>

                    {spotsLeft > 0 ? (
                      <span className="jd-spots-left">Még van {spotsLeft} szabad hely</span>
                    ) : (
                      <span className="jd-spots-left jd-spots-full">Elfogytak a helyek</span>
                    )}
                  </div>
                </div>

                <div className="jd-info-row">
                  <div className="jd-info-icon">📍</div>
                  <div className="jd-info-content">
                    <h4>Helyszín</h4>
                    <p>{job.cim}</p>
                  </div>
                </div>

                <div className="jd-map-container">
                  <img src="https://www.w3schools.com/w3images/map.jpg" alt="Térkép" className="jd-map-image" />
                  <button className="jd-map-btn">🗺️ Térkép megnyitása</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {similarJobs.length > 0 && (
          <div className="job-anim-wrapper jd-similar-section" style={{ animationDelay: '0.6s' }}>
            <h2 className="jd-card-title">Hasonló lehetőségek</h2>
            <div className="jd-similar-grid">
              {similarJobs.map((simJob) => (
                <div className="jd-similar-card job-hover-card" key={simJob.munka_id} onClick={() => navigate(`/munka-reszletek/${simJob.munka_id}`)}>
                  <div className="jd-similar-image-placeholder">🏢</div>
                  <div className="jd-similar-content">
                    <span className="jd-similar-category">{simJob.kategoria}</span>
                    <h3 className="jd-similar-title">{simJob.munka_nev}</h3>
                    <p className="jd-similar-company">{simJob.cim}</p>
                  </div>
                  <div className="jd-similar-footer">
                    <span className="jd-similar-date">📅 {formatDateTime(simJob.idopont).date}</span>
                    <span className="jd-similar-oraszamBadge">⏳ {simJob.oraszam} óra</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* MODALS */}
      {showShareModal && (
        <div className="custom-modal-overlay" onClick={() => setShowShareModal(false)}>
          <div className="custom-modal-box share-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-icon-container" style={{ backgroundColor: 'var(--sidebar-active-bg)', color: 'var(--primary-color)' }}>
              <span style={{ fontSize: '24px' }}>📤</span>
            </div>
            <h2 className="modal-alert-title">Oszd meg a munkát!</h2>
            <p className="modal-alert-text">Másold ki a hirdetés linkjét, és küldd el ismerőseidnek.</p>

            <div className="share-input-wrapper">
              <input
                type="text"
                readOnly
                value={window.location.href}
                className="share-link-input"
              />
              <button className="copy-link-btn" onClick={handleCopyLink} title="Másolás a vágólapra">
                📋
              </button>
            </div>

            <div className="modal-alert-buttons">
              <button className="modal-btn-back" style={{ width: '100%' }} onClick={() => setShowShareModal(false)}>Bezárás</button>
            </div>
          </div>
        </div>
      )}

      {showAuthModal && (
        <div className="custom-modal-overlay" onClick={() => setShowAuthModal(false)}>
          <div className="custom-modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="modal-icon-container">
              <span className="modal-icon-x">✖</span>
            </div>
            <h2 className="modal-alert-title">Bejelentkezés szükséges</h2>
            <p className="modal-alert-text">Ezt a funkciót csak bejelentkezett felhasználók használhatják!</p>
            <div className="modal-alert-buttons">
              <button className="modal-btn-back" onClick={() => setShowAuthModal(false)}>Vissza</button>
              <button className="modal-btn-login" onClick={() => navigate('/login')}>Bejelentkezés</button>
            </div>
          </div>
        </div>
      )}

      {showSuccessModal && (
        <div className="custom-modal-overlay" onClick={() => setShowSuccessModal(false)}>
          <div className="custom-modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="modal-icon-container success">
              <span className="modal-icon-check">✔</span>
            </div>
            <h2 className="modal-alert-title">Jelentkezés elküldve!</h2>
            <p className="modal-alert-text">Sikeresen jelentkeztél erre a feladatra. A cég hamarosan felveszi veled a kapcsolatot!</p>
            <div className="modal-alert-buttons">
              <button className="modal-btn-success" onClick={() => setShowSuccessModal(false)}>OK</button>
            </div>
          </div>
        </div>
      )}

      {showErrorModal && (
        <div className="custom-modal-overlay" onClick={() => setShowErrorModal(false)}>
          <div className="custom-modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="modal-icon-container">
              <span className="modal-icon-x">✖</span>
            </div>
            <h2 className="modal-alert-title">Hiba történt!</h2>
            <p className="modal-alert-text">Már egyszer jelentkeztél erre a munkára! Egy pozícióra csak egyszer adhatod le a jelentkezésedet.</p>
            <div className="modal-alert-buttons">
              <button className="modal-btn-back" onClick={() => setShowErrorModal(false)}>Vissza</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}