import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import NavbarStudent from './NavbarStudent';
import { useToast } from '../Other/ToastContext';
import './StudentDashboard.css';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export default function StudentDashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const [user, setUser] = useState({ nev: 'Betöltés...', iskola: 'Közösségi Szolgálat' });

  const [activeTab, setActiveTab] = useState('attekintes');
  const [sortBy, setSortBy] = useState('alap');
  const [expandedId, setExpandedId] = useState(null);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [settingsTab, setSettingsTab] = useState('megjelenes');
  const [darkMode, setDarkMode] = useState(localStorage.getItem('theme') === 'dark');
  const [isSaving, setIsSaving] = useState(false);

  const [warningModal, setWarningModal] = useState(false);

  const [studentData, setStudentData] = useState({
    nev: '', email: '', telefonszam: '', iskola: '', lakcim: '',
    om_azonosito: '', iskola_om_kod: '', osztaly: ''
  });

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordData, setPasswordData] = useState({ regi: '', uj: '', ujMegerosites: '' });
  const [passwordError, setPasswordError] = useState('');
  const [isPasswordSaving, setIsPasswordSaving] = useState(false);

  const [myActivities, setMyActivities] = useState([]);
  const [completedHours, setCompletedHours] = useState(0);
  const [savedJobs, setSavedJobs] = useState([]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('tab') === 'mentett') {
      setActiveTab('mentett');
    }
  }, [location]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');

    if (!token) { navigate('/login'); return; }

    if (darkMode) document.body.classList.add('dark-theme');
    else document.body.classList.remove('dark-theme');

    const fetchDashboardData = async () => {
      let jelentkezesek = [];
      let munkak = [];
      let cegek = [];

      try {
        const diakRes = await axios.get(`https://localhost:7259/api/Diak/${userId}`, { headers: { Authorization: `Bearer ${token}` } });
        if (diakRes.data) {
          const d = diakRes.data;
          const fetchedNev = d.nev || d.Nev || '';
          setStudentData({
            nev: fetchedNev,
            email: d.email || d.Email || '',
            telefonszam: d.telefonszam || d.Telefonszam || '',
            iskola: d.iskola || d.Iskola || '',
            lakcim: d.lakcim || d.Lakcim || d.cim || '',
            om_azonosito: d.om_azonosito || d.OmAzonosito || d.Om_azonosito || '',
            iskola_om_kod: d.iskola_om_kod || d.IskolaOmKod || d.Iskola_om_kod || '',
            osztaly: d.osztaly || d.Osztaly || ''
          });
          setUser({ nev: fetchedNev, iskola: d.iskola || d.Iskola || 'Regisztrált Diák' });
          localStorage.setItem('userName', fetchedNev);
        }
      } catch (err) { }

      try {
        const jelRes = await axios.get(`https://localhost:7259/api/Jelentkezes/diak/${userId}`, { headers: { Authorization: `Bearer ${token}` } });
        jelentkezesek = jelRes.data || [];
      } catch (err) { }

      try {
        const munkaRes = await axios.get(`https://localhost:7259/api/Munka`, { headers: { Authorization: `Bearer ${token}` } });
        munkak = munkaRes.data || [];

        const savedIds = JSON.parse(localStorage.getItem(`savedJobs_${userId}`) || '[]');
        const mySavedJobs = munkak.filter(m => savedIds.includes(String(m.munka_id || m.MunkaId || m.munkaId)));
        setSavedJobs(mySavedJobs);
      } catch (err) { }

      try {
        const cegRes = await axios.get(`https://localhost:7259/api/Ceg`, { headers: { Authorization: `Bearer ${token}` } });
        cegek = cegRes.data || [];
      } catch (err) { }

      let totalHours = 0;
      const activities = [];

      jelentkezesek.forEach(jel => {
        const jelMunkaId = String(jel.munka_id || jel.MunkaId || jel.munkaId);
        const jelStatus = jel.munka_statusz || jel.Munka_statusz || jel.MunkaStatusz || jel.statusz || 'Elküldve';
        const job = munkak.find(m => String(m.munka_id || m.MunkaId || m.munkaId) === jelMunkaId);

        if (job) {
          const jobCegId = String(job.ceg_id || job.CegId || job.cegId);
          const cegInfo = cegek.find(c => String(c.ceg_id || c.CegId || c.cegId) === jobCegId);
          const jobOra = Number(job.oraszam || job.Oraszam || 0);

          const approvedOra = Number(jel.jovahagyott_ora || jel.Jovahagyott_ora || jel.JovahagyottOra || jel.jovahagyottOra || 0);

          if (jelStatus.toLowerCase() === 'teljesítve' || jelStatus.toLowerCase() === 'teljesitve') {
            totalHours += approvedOra;
          }

          activities.push({
            ...jel,
            munka_id: jelMunkaId,
            munka_statusz: jelStatus,
            munka_nev: job.munka_nev || job.MunkaNev || job.munkaNev || 'Ismeretlen munka',
            oraszam: jobOra,
            jovahagyott_ora: approvedOra,
            kategoria: job.kategoria || job.Kategoria || 'Általános',
            ceg_nev: cegInfo ? (cegInfo.cegnev || cegInfo.Cegnev) : 'Ismeretlen Cég',
            helyszin: job.cim || job.Cim || 'Helyszín nem ismert',
            ceg_email: cegInfo ? (cegInfo.ceg_email || cegInfo.CegEmail || cegInfo.email || cegInfo.Email) : 'Nincs megadva email',
            igazolas_adatok: jel.igazolas_adatok || jel.Igazolas_adatok || jel.IgazolasAdatok || null
          });
        }
      });

      setCompletedHours(totalHours);
      setMyActivities(activities.reverse());
    };

    if (userId) fetchDashboardData();
  }, [navigate, darkMode]);

  const handleLogout = () => { localStorage.clear(); navigate('/'); };

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('theme', newMode ? 'dark' : 'light');
    if (newMode) document.body.classList.add('dark-theme');
    else document.body.classList.remove('dark-theme');
  };

  const handleStudentInputChange = (e) => {
    const { name, value } = e.target;
    let newValue = value;

    if (name === 'om_azonosito') {
      newValue = value.replace(/\D/g, '').slice(0, 11);
    } else if (name === 'iskola_om_kod') {
      newValue = value.replace(/\D/g, '').slice(0, 6);
    } else if (name === 'osztaly') {
      newValue = value.slice(0, 4);
    }

    setStudentData(prev => ({ ...prev, [name]: newValue }));
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    const userId = localStorage.getItem('userId');
    const token = localStorage.getItem('token');
    try {
      await axios.put(`https://localhost:7259/api/Diak/${userId}`, {
        diak_id: parseInt(userId),
        nev: studentData.nev,
        email: studentData.email,
        telefonszam: studentData.telefonszam,
        iskola: studentData.iskola,
        lakcim: studentData.lakcim,
        om_azonosito: studentData.om_azonosito ? String(studentData.om_azonosito) : null,
        iskola_om_kod: studentData.iskola_om_kod ? String(studentData.iskola_om_kod) : null,
        osztaly: studentData.osztaly,
        jelszo: "kikeruljuk_a_csharp_ellenorzest"
      }, { headers: { Authorization: `Bearer ${token}` } });

      localStorage.setItem('userName', studentData.nev);
      setUser(prev => ({ ...prev, nev: studentData.nev, iskola: studentData.iskola }));
      toast.success('Profiladatok sikeresen frissítve!'); // <-- ALERT CSERÉLVE
    } catch (error) {
      console.error(error);
      toast.error('Hiba történt a mentés során! Ellenőrizd a backend C#-ot!');
    }
    finally { setIsSaving(false); }
  };

  const handleDeleteAccount = async () => {
    const isConfirmed = window.confirm("⚠️ VIGYÁZAT! Biztosan véglegesen törölni szeretnéd a fiókodat?");
    if (isConfirmed) {
      try {
        const userId = localStorage.getItem('userId');
        const token = localStorage.getItem('token');
        await axios.delete(`https://localhost:7259/api/Diak/${userId}`, { headers: { Authorization: `Bearer ${token}` } });
        toast.success("A fiókodat sikeresen töröltük.");
        localStorage.clear(); navigate('/');
      } catch (error) { toast.error("Hiba történt a törlés során!"); }
    }
  };

  const handlePasswordInputChange = (e) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
    setPasswordError('');
  };

  const isLengthValid = passwordData.uj.length >= 8;
  const isLowerUpperValid = /(?=.*[a-z])(?=.*[A-Z])/.test(passwordData.uj);
  const isNumberValid = /(?=.*\d)/.test(passwordData.uj);
  const isSpecialValid = /(?=.*[@#$%!?&_.\-])/.test(passwordData.uj);
  const isPasswordStrongEnough = isLengthValid && isLowerUpperValid && isNumberValid && isSpecialValid;

  const handleSubmitPasswordChange = async () => {
    if (!passwordData.regi || !passwordData.uj || !passwordData.ujMegerosites) { setPasswordError('Minden mezőt ki kell tölteni!'); return; }
    if (passwordData.uj === passwordData.regi) { setPasswordError('Az új jelszó nem lehet ugyanaz, mint a régi!'); return; }
    if (passwordData.uj !== passwordData.ujMegerosites) { setPasswordError('A két új jelszó nem egyezik!'); return; }
    if (!isPasswordStrongEnough) { setPasswordError('Az új jelszó nem felel meg a biztonsági követelményeknek!'); return; }

    setIsPasswordSaving(true);
    try {
      const userId = localStorage.getItem('userId');
      const token = localStorage.getItem('token');
      await axios.put(`https://localhost:7259/api/Diak/jelszo/${userId}`, {
        RegiJelszo: passwordData.regi.trim(), UjJelszo: passwordData.uj.trim()
      }, { headers: { Authorization: `Bearer ${token}` } });

      toast.success("Jelszó sikeresen módosítva!");
      setShowPasswordModal(false);
      setPasswordData({ regi: '', uj: '', ujMegerosites: '' });
    } catch (error) {
      setPasswordError(error.response?.data?.message || 'Hiba történt a jelszó módosításakor!');
    } finally { setIsPasswordSaving(false); }
  };

  const removeSavedJob = (jobId) => {
    const userId = localStorage.getItem('userId');
    const jobIdStr = String(jobId);

    let savedIds = JSON.parse(localStorage.getItem(`savedJobs_${userId}`) || '[]');
    savedIds = savedIds.filter(id => String(id) !== jobIdStr);
    localStorage.setItem(`savedJobs_${userId}`, JSON.stringify(savedIds));

    setSavedJobs(prev => prev.filter(job => String(job.munka_id || job.MunkaId || job.munkaId) !== jobIdStr));
  };

  const getInitial = () => user.nev && user.nev !== 'Betöltés...' ? user.nev.charAt(0).toUpperCase() : '👤';

  const getStatusStyle = (status) => {
    const lowerStatus = status?.toLowerCase() || '';
    if (lowerStatus === 'elküldve' || lowerStatus === 'függőben') return { bg: 'var(--badge-pending-bg)', color: 'var(--badge-pending-text)' };
    if (lowerStatus === 'elfogadva' || lowerStatus === 'folyamatban') return { bg: 'var(--badge-progress-bg)', color: 'var(--badge-progress-text)' };
    if (lowerStatus === 'elutasítva' || lowerStatus === 'elutasitva') return { bg: 'var(--badge-rejected-bg)', color: 'var(--badge-rejected-text)' };
    if (lowerStatus === 'teljesítve' || lowerStatus === 'teljesitve') return { bg: 'var(--badge-success-bg)', color: 'var(--badge-success-text)' };
    return { bg: 'var(--badge-pending-bg)', color: 'var(--badge-pending-text)' };
  };

  const progressPercent = Math.min(100, Math.round((completedHours / 50) * 100));
  const statuszSzoveg = completedHours >= 50 ? 'Teljesítve' : (completedHours > 0 ? 'Folyamatban' : 'Kezdésre vár');

  const toggleExpand = (id) => setExpandedId(prevId => prevId === id ? null : id);

  const generatePDF = async (specificActivity = null) => {
    if (!studentData.om_azonosito || !studentData.iskola_om_kod || !studentData.osztaly) {
      setWarningModal(true);
      return;
    }

    const doc = new jsPDF();
    const normalizeHu = (text) => text?.toString().replace(/ő/g, 'ö').replace(/ű/g, 'ü').replace(/Ő/g, 'Ö').replace(/Ű/g, 'Ü') || '';

    doc.setFontSize(14);
    doc.setFont("helvetica", "bolditalic");
    doc.setTextColor(34, 139, 34);
    doc.text("ÖTVEN ÓRA", 14, 25);
    doc.setTextColor(0);

    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text(normalizeHu("KÖZÖSSÉGI SZOLGÁLATI NAPLÓ"), 105, 30, { align: "center" });

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Tanuló neve: ${normalizeHu(studentData.nev)}`, 14, 45);
    doc.text(`Osztálya: ${normalizeHu(studentData.osztaly)}`, 95, 45);
    doc.text(`Oktatási azonosítója: ${studentData.om_azonosito}`, 145, 45);

    doc.text(`Iskola OM kódja: ${studentData.iskola_om_kod}`, 14, 55);
    doc.text(`Iskola neve: ${normalizeHu(studentData.iskola)}`, 95, 55);

    let activitiesToProcess = [];
    if (specificActivity) {
      activitiesToProcess = [specificActivity];
    } else {
      activitiesToProcess = myActivities.filter(act =>
        act.munka_statusz?.toLowerCase() === 'teljesítve' || act.munka_statusz?.toLowerCase() === 'teljesitve'
      );
    }

    const tableBody = [];
    const signaturesMap = {};
    let calculatedTotalHours = 0;

    activitiesToProcess.forEach(act => {
      if (act.igazolas_adatok) {
        try {
          const recipe = JSON.parse(act.igazolas_adatok);
          const [daysStr, hoursStr] = recipe.formatum.split('*');
          const totalDays = parseInt(daysStr, 10);
          const hoursPerDay = parseInt(hoursStr, 10);
          let currentDate = new Date(recipe.kezdodatum);

          for (let i = 0; i < totalDays; i++) {
            const dateString = `${currentDate.getFullYear()}.${String(currentDate.getMonth() + 1).padStart(2, '0')}.${String(currentDate.getDate()).padStart(2, '0')}.`;

            signaturesMap[tableBody.length] = recipe.alairas_base64;

            tableBody.push([
              dateString,
              hoursPerDay.toString(),
              normalizeHu(`${recipe.kategoria} - ${recipe.munka_nev}`),
              "",
              normalizeHu(recipe.ceg_nev)
            ]);

            calculatedTotalHours += hoursPerDay;
            currentDate.setDate(currentDate.getDate() + 1);
          }
        } catch (e) { console.error("Hibás JSON recept", e); }
      }
    });

    if (tableBody.length === 0) {
      tableBody.push(["", "", normalizeHu("Nincs még hitelesített munka"), "", ""]);
    }

    autoTable(doc, {
      startY: 65,
      head: [['Dátum', 'Teljesített\nóra', 'Feladat(ok)\nleírása', 'Tanácsadó-mentor\naláírása', 'Fogadó cég neve']],
      body: tableBody,
      theme: 'grid',
      headStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], lineColor: [34, 139, 34], lineWidth: 0.5, halign: 'center', valign: 'middle', fontStyle: 'bold', minCellHeight: 15 },
      bodyStyles: { lineColor: [34, 139, 34], lineWidth: 0.5, minCellHeight: 25, valign: 'middle' },
      styles: { font: "helvetica", fontSize: 10, textColor: [20, 20, 20] },
      columnStyles: { 0: { cellWidth: 25 }, 1: { cellWidth: 25, halign: 'center' }, 2: { cellWidth: 'auto' }, 3: { cellWidth: 35 }, 4: { cellWidth: 35 } },

      didDrawCell: function (data) {
        if (data.column.index === 3 && data.section === 'body') {
          const sig = signaturesMap[data.row.index];
          if (sig) {
            doc.addImage(sig, 'PNG', data.cell.x + 2, data.cell.y + 2, 30, 10);
          }
        }
      }
    });

    const finalY = doc.lastAutoTable.finalY + 15;

    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text(normalizeHu(`Összes óra: ${calculatedTotalHours}`), 14, finalY);

    const today = new Date();
    const todayStr = `${today.getFullYear()}.${String(today.getMonth() + 1).padStart(2, '0')}.${String(today.getDate()).padStart(2, '0')}.`;
    doc.setFont("helvetica", "normal");
    doc.text(normalizeHu(`Lezárva (dátum): ${todayStr}`), 135, finalY);

    const authCode = `OTVEN-${today.getFullYear()}${today.getMonth() + 1}${today.getDate()}-${Math.floor(Math.random() * 10000)}`;
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text(normalizeHu(`Elektronikusan generált igazolás. Azonosító: ${authCode}`), 14, 285);

    doc.save(`Kozossegi_Szolgalat_${normalizeHu(studentData.nev).replace(/\s+/g, '_')}.pdf`);
  };


  const renderActivityCard = (act, index) => {
    const statusStyle = getStatusStyle(act.munka_statusz);
    const isExpanded = expandedId === act.munka_id;
    const isCompleted = act.munka_statusz?.toLowerCase() === 'teljesítve' || act.munka_statusz?.toLowerCase() === 'teljesitve';

    return (
      <div key={index} className="hover-card base-card" onClick={() => toggleExpand(act.munka_id)} style={{ padding: '20px', display: 'flex', flexDirection: 'column', cursor: 'pointer', transition: 'all 0.3s ease', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: '12px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
          <div>
            <h4 style={{ margin: '0 0 8px 0', fontSize: '17px', color: 'var(--text-main)' }}>💼 {act.munka_nev}</h4>
            <div style={{ fontSize: '14px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '15px', flexWrap: 'wrap' }}>
              <span>🏢 {act.ceg_nev}</span>
              <span>🏷️ {act.kategoria}</span>
              {isCompleted ? (
                <span style={{ color: 'var(--badge-success-text)', fontWeight: 'bold' }}>⏳ {act.jovahagyott_ora} óra jóváhagyva</span>
              ) : (
                <span style={{ fontStyle: 'italic', opacity: 0.7 }} title="A cég a teljesítés után határozza meg az óraszámot.">⏳ Értékelés alatt</span>
              )}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <span style={{ backgroundColor: statusStyle.bg, color: statusStyle.color, padding: '6px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 'bold', textTransform: 'uppercase' }}>{act.munka_statusz}</span>
            <span style={{ fontSize: '16px', color: 'var(--text-muted)', transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.4s ease-in-out' }}>▼</span>
          </div>
        </div>

        <div style={{ maxHeight: isExpanded ? '200px' : '0px', opacity: isExpanded ? 1 : 0, overflow: 'hidden', transition: 'all 0.4s ease-in-out', marginTop: isExpanded ? '15px' : '0px' }}>
          <div style={{ paddingTop: '15px', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '20px' }}>
            <div style={{ display: 'flex', gap: '40px', flexWrap: 'wrap' }}>
              <div><p style={{ margin: '0 0 5px 0', fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 'bold' }}>Helyszín</p><p style={{ margin: 0, fontSize: '14px', color: 'var(--text-main)' }}>📍 {act.helyszin}</p></div>
              <div><p style={{ margin: '0 0 5px 0', fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 'bold' }}>Kapcsolat felvétele</p><p style={{ margin: 0, fontSize: '14px', color: 'var(--primary-color)', fontWeight: '500' }}>✉️ {act.ceg_email}</p></div>
            </div>

            {isCompleted && (
              <button
                className="btn-outline"
                onClick={(e) => {
                  e.stopPropagation();
                  generatePDF(act);
                }}
                style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 'bold' }}
              >
                📄 Részleges igazolás
              </button>
            )}

          </div>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    if (activeTab === 'attekintes') {
      return (
        <>
          <section className="stats-grid" style={{ marginBottom: '30px' }}>
            <div className="dash-anim-wrapper">
              <div className="stat-card base-card" style={{ padding: '25px', borderRadius: '16px', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
                  <div><h2 style={{ margin: '0 0 5px 0', fontSize: '18px', color: 'var(--text-main)' }}>Érettségi követelmény</h2><p style={{ margin: 0, fontSize: '14px', color: 'var(--text-muted)' }}>A kötelező 50 óra teljesítése</p></div>
                  <span style={{ padding: '5px 12px', backgroundColor: completedHours >= 50 ? 'var(--badge-success-bg)' : (completedHours > 0 ? 'var(--badge-pending-bg)' : 'var(--bg-main)'), color: completedHours >= 50 ? 'var(--badge-success-text)' : (completedHours > 0 ? 'var(--primary-color)' : 'var(--text-muted)'), borderRadius: '20px', fontSize: '12px', fontWeight: 'bold' }}>{statuszSzoveg}</span>
                </div>
                <div className="progress-section">
                  <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: '10px' }}><span style={{ fontSize: '36px', fontWeight: '800', color: 'var(--text-main)' }}>{completedHours}</span><span style={{ fontSize: '16px', marginLeft: '8px', color: 'var(--text-muted)' }}>/ 50 óra</span><span style={{ marginLeft: 'auto', fontSize: '18px', fontWeight: 'bold', color: 'var(--primary-color)' }}>{progressPercent}%</span></div>
                  <div style={{ width: '100%', height: '12px', backgroundColor: 'var(--bg-main)', borderRadius: '10px', overflow: 'hidden', border: '1px solid var(--border-color)' }}><div style={{ width: `${progressPercent}%`, height: '100%', backgroundColor: 'var(--primary-color)', borderRadius: '10px', transition: 'width 1s ease-in-out' }}></div></div>
                </div>
              </div>
            </div>
          </section>

          <section className="content-grid">
            <div className="dash-anim-wrapper">
              <div className="table-card base-card" style={{ padding: '25px', borderRadius: '16px', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '15px', marginBottom: '20px' }}>
                  <h3 style={{ margin: 0, fontSize: '18px', color: 'var(--text-main)' }}>Részletes tevékenységek</h3>
                  {myActivities.length > 0 && (<span style={{ color: 'var(--primary-color)', fontSize: '14px', fontWeight: 'bold', cursor: 'pointer' }} onClick={() => setActiveTab('tevekenysegek')}>Összes megtekintése →</span>)}
                </div>
                {myActivities.length === 0 ? (
                  <div style={{ padding: '40px 20px', textAlign: 'center' }}>
                    <div style={{ fontSize: '48px', marginBottom: '15px' }}>📭</div><h4 style={{ margin: '0 0 10px 0', fontSize: '18px', color: 'var(--text-main)' }}>Még nincsenek rögzített óráid</h4><p style={{ margin: '0 0 25px 0', maxWidth: '400px', marginLeft: 'auto', marginRight: 'auto', color: 'var(--text-muted)' }}>Jelenleg egyetlen aktív közösségi szolgálatod sincs.</p>
                    <button onClick={() => navigate('/munkak')} style={{ padding: '10px 24px', backgroundColor: 'var(--bg-main)', color: 'var(--primary-color)', border: '1px solid var(--border-color)', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold' }}>Munkák böngészése →</button>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>{myActivities.slice(0, 3).map((act, index) => renderActivityCard(act, index))}</div>
                )}
              </div>
            </div>
          </section>
        </>
      );
    }
    else if (activeTab === 'tevekenysegek') {
      const sortedActivities = [...myActivities].sort((a, b) => {
        if (sortBy === 'statusz') return a.munka_statusz.localeCompare(b.munka_statusz);
        if (sortBy === 'ceg') return a.ceg_nev.localeCompare(b.ceg_nev);
        if (sortBy === 'kategoria') return a.kategoria.localeCompare(b.kategoria);
        const oraszamA = a.jovahagyott_ora || 0;
        const oraszamB = b.jovahagyott_ora || 0;
        if (sortBy === 'oraszam') return oraszamB - oraszamA;
        return 0;
      });

      return (
        <section className="content-grid">
          <div className="dash-anim-wrapper">
            <div className="table-card base-card" style={{ padding: '30px', borderRadius: '16px', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '15px', marginBottom: '20px', flexWrap: 'wrap', gap: '15px' }}>
                <h3 style={{ margin: 0, fontSize: '20px', color: 'var(--text-main)' }}>📋 Összes tevékenységem</h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style={{ fontSize: '20px' }}>🎛️</span>
                  <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} style={{ padding: '8px 12px', borderRadius: '8px', outline: 'none', cursor: 'pointer', fontWeight: '600', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }}>
                    <option value="alap">Legfrissebb elöl</option><option value="statusz">Csoportosítás: Státusz szerint</option><option value="ceg">Csoportosítás: Cég szerint</option><option value="kategoria">Csoportosítás: Kategória szerint</option><option value="oraszam">Óraszám (legtöbb elöl)</option>
                  </select>
                </div>
              </div>
              {sortedActivities.length === 0 ? (
                <p style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>Nincs még rögzített tevékenységed.</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', maxHeight: '650px', overflowY: 'auto', paddingRight: '10px' }}>{sortedActivities.map((act, index) => renderActivityCard(act, index))}</div>
              )}
            </div>
          </div>
        </section>
      );
    }
    else if (activeTab === 'mentett') {
      return (
        <section className="content-grid">
          <div className="dash-anim-wrapper">
            <div className="table-card base-card" style={{ padding: '30px', borderRadius: '16px', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '15px', marginBottom: '20px' }}>
                <h3 style={{ margin: 0, fontSize: '20px', color: 'var(--text-main)' }}>⭐ Mentett munkáim</h3>
                <span style={{ backgroundColor: 'var(--bg-main)', padding: '5px 12px', borderRadius: '20px', fontSize: '13px', fontWeight: 'bold', color: 'var(--text-muted)', border: '1px solid var(--border-color)' }}>{savedJobs.length} mentett hirdetés</span>
              </div>

              {savedJobs.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                  <div style={{ fontSize: '48px', marginBottom: '15px', opacity: 0.5 }}>⭐</div>
                  <h4 style={{ margin: '0 0 10px 0', fontSize: '18px', color: 'var(--text-main)' }}>Nincsenek mentett munkáid</h4>
                  <p style={{ margin: '0 0 25px 0', color: 'var(--text-muted)' }}>Böngéssz a munkák között, és mentsd el azokat, amik tetszenek!</p>
                  <button onClick={() => navigate('/munkak')} style={{ padding: '10px 24px', backgroundColor: 'var(--primary-color)', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold' }}>Munkák böngészése →</button>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                  {savedJobs.map((job) => {
                    const id = job.munka_id || job.MunkaId || job.munkaId;
                    return (
                      <div key={id} className="hover-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px', backgroundColor: 'var(--bg-main)', border: '1px solid var(--border-color)', borderRadius: '12px', transition: 'all 0.2s ease' }}>
                        <div>
                          <h4 style={{ margin: '0 0 8px 0', fontSize: '17px', color: 'var(--text-main)' }}>{job.munka_nev || job.MunkaNev || job.munkaNev}</h4>
                          <span style={{ fontSize: '14px', color: 'var(--text-muted)' }}>📍 {job.cim || job.Cim} • ⏳ Max {job.oraszam || job.Oraszam} óra</span>
                        </div>
                        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                          <button onClick={() => navigate(`/munka-reszletek/${id}`)} className="saved-job-details-btn">
                            Részletek
                          </button>
                          <button onClick={() => removeSavedJob(id)} className="saved-job-remove-btn">
                            Eltávolítás
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </section>
      );
    }
  };

  return (
    <>
      <style>{`
        @keyframes slideFadeIn { from { opacity: 0; transform: translateY(-15px); } to { opacity: 1; transform: translateY(0); } }
        .tab-content-anim { animation: slideFadeIn 0.4s ease-out forwards; }
      `}</style>

      <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)' }}>
        <NavbarStudent />

        <div className="mobile-header">
          <div className="mobile-brand">
            <span className="brand-icon">🎓</span>
            <h2>Diák Panel</h2>
          </div>
          <button className="hamburger-btn" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? '✕' : '☰'}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="sidebar-overlay" onClick={() => setIsMobileMenuOpen(false)}></div>
        )}

        <div className="dashboard-container" style={{ flex: 1, height: 'auto' }}>

          <aside className={`sidebar ${isMobileMenuOpen ? 'open' : ''}`}>
            <button
              className="sidebar-close-btn"
              onClick={() => setIsMobileMenuOpen(false)}
              style={{ position: 'absolute', top: '20px', right: '20px', background: 'none', border: 'none', fontSize: '24px', color: 'var(--text-muted)', cursor: 'pointer' }}
            >
              ✕
            </button>

            <div className="user-profile">
              <div className="avatar-placeholder" style={{ width: '50px', height: '50px', borderRadius: '50%', backgroundColor: 'var(--primary-color)', color: '#ffffff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', fontWeight: 'bold' }}>{getInitial()}</div>
              <div className="user-info"><h3 style={{ color: 'var(--text-main)' }}>{user.nev}</h3><p style={{ color: 'var(--text-muted)' }}>{user.iskola}</p></div>
            </div>

            <nav className="sidebar-nav">
              <a href="#" className={`nav-item ${activeTab === 'attekintes' ? 'active' : ''}`} onClick={(e) => { e.preventDefault(); setActiveTab('attekintes'); setIsMobileMenuOpen(false); }}><span style={{ marginRight: '10px' }}>📊</span> Áttekintés</a>
              <a href="#" className={`nav-item ${activeTab === 'tevekenysegek' ? 'active' : ''}`} onClick={(e) => { e.preventDefault(); setActiveTab('tevekenysegek'); setIsMobileMenuOpen(false); }}><span style={{ marginRight: '10px' }}>📋</span> Tevékenységeim</a>
              <a href="#" className={`nav-item ${activeTab === 'mentett' ? 'active' : ''}`} onClick={(e) => { e.preventDefault(); setActiveTab('mentett'); setIsMobileMenuOpen(false); }}>
                <span style={{ marginRight: '10px' }}>⭐</span> Mentett munkáim
                {savedJobs.length > 0 && <span style={{ marginLeft: 'auto', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', fontSize: '11px', padding: '2px 8px', borderRadius: '10px', border: '1px solid var(--border-color)' }}>{savedJobs.length}</span>}
              </a>
              <a href="#" className="nav-item" onClick={(e) => { e.preventDefault(); navigate('/munkak'); setIsMobileMenuOpen(false); }}><span style={{ marginRight: '10px' }}>💼</span> Munkakeresés</a>


              <a href="#" className="nav-item" onClick={(e) => { e.preventDefault(); navigate('/'); setIsMobileMenuOpen(false); }}>
                <span style={{ marginRight: '10px' }}>🏠</span> Főoldal
              </a>

              <a href="#" className="nav-item" onClick={(e) => { e.preventDefault(); setShowSettingsModal(true); setSettingsTab('megjelenes'); setIsMobileMenuOpen(false); }}><span style={{ marginRight: '10px' }}>⚙️</span> Beállítások</a>
            </nav>

            <div className="sidebar-bottom">
              <button className="logout-btn" onClick={handleLogout} style={{ width: '100%', padding: '12px', background: 'transparent', border: 'none', color: 'var(--danger-color)', fontWeight: 'bold', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}>🚪 Kijelentkezés</button>
            </div>
          </aside>

          <main className="dashboard-main">
            <header className="main-header" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '30px' }}>
              <div>
                <h1 style={{ margin: '0 0 5px 0', fontSize: '28px', color: 'var(--text-main)' }}>
                  {activeTab === 'attekintes' ? 'Irányítópult' : activeTab === 'tevekenysegek' ? 'Tevékenységeim' : 'Mentett munkáim'}
                </h1>
                <p style={{ margin: 0, color: 'var(--text-muted)' }}>
                  {activeTab === 'attekintes' ? `Üdvözöljük újra, ${user.nev.split(' ')[0]}! Itt láthatod a közösségi szolgálatod előrehaladását.` :
                    activeTab === 'tevekenysegek' ? 'Böngéssz az eddigi összes jelentkezésed és elvégzett munkád között.' :
                      'Itt találod azokat a hirdetéseket, amiket későbbre elmentettél.'}
                </p>
              </div>
              {activeTab === 'attekintes' && (
                <button
                  className={`main-download-btn ${completedHours >= 50 ? 'active' : 'disabled'}`}
                  disabled={completedHours < 50}
                  title={completedHours >= 50 ? "Összesített igazolás letöltése" : "Az igazolás letöltése 50 jóváhagyott óra elérése után válik elérhetővé."}
                  onClick={() => generatePDF(null)}
                >
                  📄 Igazolás letöltése
                </button>
              )}
            </header>
            {renderContent()}
          </main>
        </div>
      </div>


      {showSettingsModal && (
        <div className="custom-modal-overlay" onClick={() => setShowSettingsModal(false)} style={{ backdropFilter: 'blur(8px)', backgroundColor: 'rgba(0, 0, 0, 0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 3000 }}>
          <div className="custom-modal-box settings-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '1000px', width: '90%', height: '700px', padding: 0, borderRadius: '16px', display: 'flex', overflow: 'hidden', position: 'relative', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>

            <div className="settings-sidebar" style={{ width: '260px', borderRight: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', paddingTop: '30px', backgroundColor: 'var(--bg-main)' }}>
              <h2 style={{ fontSize: '20px', padding: '0 20px', marginBottom: '20px', color: 'var(--text-main)' }}>⚙️ Beállítások</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <button className={`settings-nav-btn ${settingsTab === 'megjelenes' ? 'active' : ''}`} onClick={() => setSettingsTab('megjelenes')}>🎨 Megjelenés</button>
                <button className={`settings-nav-btn ${settingsTab === 'adatok' ? 'active' : ''}`} onClick={() => setSettingsTab('adatok')}>✏️ Adatok szerkesztése</button>
                <button className={`settings-nav-btn ${settingsTab === 'dokumentum' ? 'active' : ''}`} onClick={() => setSettingsTab('dokumentum')}>📄 Dokumentum</button>
                <button className={`settings-nav-btn danger ${settingsTab === 'fiok' ? 'active' : ''}`} onClick={() => setSettingsTab('fiok')}>🔒 Fiókbeállítások</button>
              </div>
            </div>

            <div className="settings-content" style={{ flex: 1, padding: '40px', position: 'relative', overflowY: 'auto', backgroundColor: 'var(--bg-card)' }}>
              <button className="settings-close-btn" onClick={() => setShowSettingsModal(false)} style={{ position: 'absolute', top: '20px', right: '25px', border: 'none', width: '36px', height: '36px', borderRadius: '50%', fontSize: '16px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'var(--bg-main)', color: 'var(--text-muted)' }}>✖</button>
              <div key={settingsTab} className="tab-content-anim">

                {settingsTab === 'megjelenes' && (
                  <div>
                    <h3 style={{ fontSize: '22px', marginBottom: '25px', borderBottom: '2px solid var(--border-color)', paddingBottom: '10px', color: 'var(--text-main)' }}>Megjelenés</h3>
                    <div className="settings-inner-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-main)' }}>
                      <div><strong style={{ display: 'block', fontSize: '16px', color: 'var(--text-main)' }}>Sötét mód (Dark Mode)</strong><span style={{ fontSize: '14px', color: 'var(--text-muted)' }}>Kíméletesebb a szemnek.</span></div>
                      <button onClick={toggleDarkMode} className="theme-toggle-btn" style={{ padding: '10px 20px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', borderRadius: '30px', cursor: 'pointer', fontWeight: 'bold', transition: 'all 0.3s' }}>{darkMode ? '🌙 Bekapcsolva' : '☀️ Kikapcsolva'}</button>
                    </div>
                  </div>
                )}

                {settingsTab === 'adatok' && (
                  <div>
                    <h3 style={{ fontSize: '22px', marginBottom: '25px', borderBottom: '2px solid var(--border-color)', paddingBottom: '10px', color: 'var(--text-main)' }}>Adatok szerkesztése</h3>
                    <div className="settings-inner-card" style={{ padding: '25px', borderRadius: '12px', border: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', gap: '20px', backgroundColor: 'var(--bg-main)' }}>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                        <div><label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px', color: 'var(--text-main)' }}>Teljes név</label><input type="text" name="nev" value={studentData.nev} onChange={handleStudentInputChange} style={{ width: '100%', padding: '12px 15px', borderRadius: '8px', outline: 'none', fontSize: '15px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
                        <div><label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px', color: 'var(--text-main)' }}>Iskola / Intézmény</label><input type="text" name="iskola" value={studentData.iskola} onChange={handleStudentInputChange} style={{ width: '100%', padding: '12px 15px', borderRadius: '8px', outline: 'none', fontSize: '15px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                        <div><label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px', color: 'var(--text-main)' }}>Telefonszám</label><input type="text" name="telefonszam" value={studentData.telefonszam} onChange={handleStudentInputChange} style={{ width: '100%', padding: '12px 15px', borderRadius: '8px', outline: 'none', fontSize: '15px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
                        <div><label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px', color: 'var(--text-main)' }}>Email cím</label><input type="email" name="email" value={studentData.email} onChange={handleStudentInputChange} style={{ width: '100%', padding: '12px 15px', borderRadius: '8px', outline: 'none', fontSize: '15px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
                      </div>
                      <button onClick={handleSaveProfile} disabled={isSaving} style={{ alignContent: 'center', justifyContent: 'center', alignSelf: 'flex-start', marginTop: '10px', padding: '12px 24px', backgroundColor: 'var(--primary-color)', color: '#ffffff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '15px' }}>{isSaving ? '⏳ Mentés...' : '💾 Változtatások mentése'}</button>
                    </div>
                    <h4 style={{ textTransform: 'uppercase', fontSize: '13px', letterSpacing: '1px', marginBottom: '10px', marginTop: '30px', color: 'var(--text-muted)' }}>Biztonság</h4>
                    <div className="settings-inner-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-main)' }}>
                      <div><strong style={{ display: 'block', fontSize: '16px', color: 'var(--text-main)' }}>Jelszó módosítása</strong><span style={{ fontSize: '14px', color: 'var(--text-muted)' }}>A fiókod biztonsága érdekében.</span></div>
                      <button onClick={() => setShowPasswordModal(true)} style={{ alignContent: 'center', justifyContent: 'center', alignSelf: 'center', padding: '10px 20px', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }}>🔑 Új jelszó kérése</button>
                    </div>
                  </div>
                )}

                {settingsTab === 'dokumentum' && (
                  <div>
                    <h3 style={{ fontSize: '22px', marginBottom: '25px', borderBottom: '2px solid var(--border-color)', paddingBottom: '10px', color: 'var(--text-main)' }}>Hivatalos Igazolás Adatai</h3>
                    <p style={{ color: 'var(--text-muted)', marginBottom: '20px' }}>Ezek az adatok kötelezőek a hivatalos Közösségi Szolgálati Napló letöltéséhez. Az adatokat pontosan a diákigazolványod/iskolád adatai alapján töltsd ki!</p>

                    <div className="settings-inner-card" style={{ padding: '25px', borderRadius: '12px', border: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', gap: '20px', backgroundColor: 'var(--bg-main)' }}>
                      <div>
                        <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px', color: 'var(--text-main)' }}>Oktatási azonosító (11 jegyű szám)</label>
                        <input type="text" name="om_azonosito" placeholder="pl. 71234567890" value={studentData.om_azonosito} onChange={handleStudentInputChange} style={{ width: '100%', padding: '12px 15px', borderRadius: '8px', outline: 'none', fontSize: '15px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} />
                      </div>

                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
                        <div>
                          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px', color: 'var(--text-main)' }}>Iskola OM kódja (6 jegyű szám)</label>
                          <input type="text" name="iskola_om_kod" placeholder="pl. 035123" value={studentData.iskola_om_kod} onChange={handleStudentInputChange} style={{ width: '100%', padding: '12px 15px', borderRadius: '8px', outline: 'none', fontSize: '15px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} />
                        </div>
                        <div>
                          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', fontSize: '14px', color: 'var(--text-main)' }}>Osztályod</label>
                          <input type="text" name="osztaly" placeholder="pl. 10.B" value={studentData.osztaly} onChange={handleStudentInputChange} style={{ width: '100%', padding: '12px 15px', borderRadius: '8px', outline: 'none', fontSize: '15px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} />
                        </div>
                      </div>

                      <button onClick={handleSaveProfile} disabled={isSaving} style={{ alignSelf: 'flex-start', marginTop: '10px', padding: '12px 24px', backgroundColor: 'var(--primary-color)', color: '#ffffff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '15px' }}>
                        {isSaving ? '⏳ Mentés...' : '💾 Mentés'}
                      </button>
                    </div>
                  </div>
                )}

                {settingsTab === 'fiok' && (
                  <div>
                    <h3 style={{ fontSize: '22px', marginBottom: '25px', borderBottom: '2px solid var(--border-color)', paddingBottom: '10px', color: 'var(--text-main)' }}>Fiókbeállítások</h3>

                    <div className="settings-danger-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '25px', borderRadius: '12px', backgroundColor: 'var(--danger-bg)', border: '1px solid var(--danger-border)' }}>
                      <div><strong style={{ display: 'block', color: 'var(--danger-color)', fontSize: '16px' }}>Fiók végleges törlése</strong><span style={{ fontSize: '14px', color: 'var(--danger-color)' }}>Minden adatod elvész.</span></div>
                      <button onClick={handleDeleteAccount} style={{ padding: '12px 24px', backgroundColor: 'var(--danger-color)', color: '#ffffff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '15px' }}>🗑️ Fiók törlése</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {showPasswordModal && (
        <div className="custom-modal-overlay" onClick={() => setShowPasswordModal(false)} style={{ zIndex: 3050, backdropFilter: 'blur(3px)', backgroundColor: 'rgba(0, 0, 0, 0.6)' }}>
          <div className="custom-modal-box base-card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '400px', width: '90%', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', padding: '25px', borderRadius: '12px' }}>
            <h2 style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '10px', marginBottom: '20px', color: 'var(--text-main)' }}>Jelszó módosítása</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
              <div><label style={{ display: 'block', fontSize: '13px', fontWeight: 'bold', marginBottom: '5px', color: 'var(--text-muted)' }}>Régi jelszó</label><input type="password" name="regi" value={passwordData.regi} onChange={handlePasswordInputChange} style={{ width: '100%', padding: '10px', borderRadius: '6px', outline: 'none', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
              <div><label style={{ display: 'block', fontSize: '13px', fontWeight: 'bold', marginBottom: '5px', color: 'var(--text-muted)' }}>Új jelszó</label><input type="password" name="uj" value={passwordData.uj} onChange={handlePasswordInputChange} style={{ width: '100%', padding: '10px', borderRadius: '6px', outline: 'none', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
              <div><label style={{ display: 'block', fontSize: '13px', fontWeight: 'bold', marginBottom: '5px', color: 'var(--text-muted)' }}>Új jelszó még egyszer</label><input type="password" name="ujMegerosites" value={passwordData.ujMegerosites} onChange={handlePasswordInputChange} style={{ width: '100%', padding: '10px', borderRadius: '6px', outline: 'none', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
              {passwordData.uj.length > 0 && !isPasswordStrongEnough && (
                <div style={{ fontSize: '12px', color: 'var(--danger-color)', backgroundColor: 'var(--danger-bg)', border: '1px solid var(--danger-border)', padding: '10px', borderRadius: '6px', marginTop: '5px' }}>
                  <strong style={{ display: 'block', marginBottom: '5px' }}>Hiányzó feltételek:</strong>
                  {!isLengthValid && <div>• Legalább 8 karakter</div>}
                  {!isLowerUpperValid && <div>• Kis- és nagybetű</div>}
                  {!isNumberValid && <div>• Legalább egy szám</div>}
                  {!isSpecialValid && <div>• Speciális karakter (@#$%!?&_.-)</div>}
                </div>
              )}
              {passwordError && <div style={{ fontSize: '13px', color: 'var(--danger-color)', fontWeight: 'bold', textAlign: 'center', marginTop: '5px' }}>❌ {passwordError}</div>}
              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button onClick={() => setShowPasswordModal(false)} style={{ flex: 1, padding: '10px', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }}>Mégse</button>
                <button onClick={handleSubmitPasswordChange} disabled={isPasswordSaving} style={{ flex: 1, padding: '10px', backgroundColor: 'var(--primary-color)', color: '#ffffff', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>Mentés</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {warningModal && (
        <div className="custom-modal-overlay" onClick={() => setWarningModal(false)} style={{ zIndex: 4000, backdropFilter: 'blur(3px)', backgroundColor: 'rgba(0,0,0,0.6)' }}>
          <div className="custom-modal-box" onClick={(e) => e.stopPropagation()} style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', maxWidth: '450px', textAlign: 'center' }}>
            <div className="modal-icon-container" style={{ backgroundColor: '#fef9c3', color: '#eab308', margin: '0 auto 20px auto', width: '60px', height: '60px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: '30px' }}>⚠️</span>
            </div>
            <h2 className="modal-alert-title" style={{ color: 'var(--text-main)', marginBottom: '10px' }}>Hiányzó adatok!</h2>
            <p className="modal-alert-text" style={{ color: 'var(--text-muted)', marginBottom: '20px', lineHeight: '1.5' }}>
              A dokumentum letöltéséhez kérjük, töltsd ki az <strong>Oktatási azonosítót</strong>, az <strong>Iskola OM kódját</strong> és az <strong>Osztályodat</strong> a Beállításoknál!
            </p>
            <div className="modal-alert-buttons" style={{ display: 'flex', gap: '15px', justifyContent: 'center', marginTop: '20px' }}>
              <button className="modal-btn-back" style={{ backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', borderColor: 'var(--border-color)', flex: 1 }} onClick={() => setWarningModal(false)}>Mégse</button>
              <button
                className="modal-btn-success"
                style={{ flex: 1 }}
                onClick={() => {
                  setWarningModal(false);
                  setShowSettingsModal(true);
                  setSettingsTab('dokumentum');
                }}
              >
                Beállítások
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}