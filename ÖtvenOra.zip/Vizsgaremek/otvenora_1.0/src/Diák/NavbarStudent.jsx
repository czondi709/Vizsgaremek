import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import './NavbarStudent.css';

export default function NavbarStudent() {
  const navigate = useNavigate();
  const [userName, setUserName] = useState('');
  const [completedHours, setCompletedHours] = useState(0);
  const [darkMode, setDarkMode] = useState(localStorage.getItem('theme') === 'dark');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const name = localStorage.getItem('userName');
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    setUserName(name || 'Diák');

    const fetchHours = async () => {
      if (!token || !userId) return;

      try {
        const diakRes = await axios.get(`https://localhost:7259/api/Diak/${userId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (diakRes.data) {
          const hours = Number(diakRes.data.ledolgozott_ora || diakRes.data.Ledolgozott_ora || 0);
          setCompletedHours(hours);
        }
      } catch (error) {
        console.error("Hiba az óraszámok lekérésekor a Navbarban:", error);
      }
    };

    fetchHours();

    if (darkMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('theme', newMode ? 'dark' : 'light');
    if (newMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  };

  const handleNavClick = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  const getBadgeColor = () => {
    if (completedHours <= 15) return '#ef4444';
    if (completedHours <= 35) return '#f97316';
    return '#22c55e';
  };

  return (
    <nav className="student-navbar">
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        <div className="navbar-logo" onClick={() => handleNavClick('/')}>
          <span className="logo-icon">🎓</span>
          <span className="logo-text">Ötven óra</span>
        </div>

        <button
          onClick={toggleDarkMode}
          className="guest-theme-toggle"
          title={darkMode ? "Világos mód bekapcsolása" : "Sötét mód bekapcsolása"}
        >
          {darkMode ? '☀️' : '🌙'}
        </button>
      </div>

      <button
        className="navbar-hamburger"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        style={{ color: 'var(--text-main)' }}
      >
        {isMobileMenuOpen ? (

          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        ) : (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        )}
      </button>

      <div className={`student-right-section ${isMobileMenuOpen ? 'open' : ''}`} style={{ display: 'flex', alignItems: 'center', flex: 1, justifyContent: 'space-between' }}>

        <div className="navbar-links">
          <span onClick={() => handleNavClick('/munkak')} className="nav-link" style={{ cursor: 'pointer' }}>Munkák</span>
          <span onClick={() => handleNavClick('/profil')} className="nav-link" style={{ cursor: 'pointer' }}>Irányítópult</span>
          <span onClick={() => handleNavClick('/segitseg')} className="nav-link" style={{ cursor: 'pointer' }}>Segítség</span>

          <div
            className="hours-badge"
            title="Eddig teljesített órák"
            style={{
              borderColor: getBadgeColor(),
              color: getBadgeColor(),
            }}
          >
            ⏱️ {completedHours} / 50 óra
          </div>
        </div>

        <div className="navbar-profile-section">
          <span className="user-name-text">
            {userName}
          </span>
          <div
            onClick={() => handleNavClick('/profil')}
            title="Ugrás az Irányítópultra"
            className="user-profile-icon"
          >
            👤
          </div>
        </div>
      </div>
    </nav>
  );
}