import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import DynamicNavbar from '../Other/DynamicNavbar';
import { useToast } from '../Other/ToastContext';
import '../Munka/UjHirdetes.css';

export default function MunkaSzerkesztes() {
  const navigate = useNavigate();
  const { id } = useParams();
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    const isDark = localStorage.getItem('theme') === 'dark';
    if (isDark) document.body.classList.add('dark-theme');
    else document.body.classList.remove('dark-theme');
  }, []);

  const categories = [
    { id: 'környezetvédelem', label: 'Környezetvédelem', icon: '🌳' },
    { id: 'állatvédelem', label: 'Állatvédelem', icon: '🐾' },
    { id: 'szociális', label: 'Szociális', icon: '🤝' },
    { id: 'idősgondozás', label: 'Idősgondozás', icon: '👵' },
    { id: 'kulturális', label: 'Kulturális', icon: '🏛️' },
    { id: 'közművelődés', label: 'Közművelődés', icon: '🎭' },
    { id: 'oktatás', label: 'Oktatás', icon: '🎓' },
    { id: 'sport', label: 'Sport', icon: '⚽' },
    { id: 'egészségügyi', label: 'Egészségügyi', icon: '🏥' },
    { id: 'katasztrófavédelem', label: 'Katasztrófavédelem', icon: '🚒' }
  ];

  const [jobData, setJobData] = useState({
    munka_nev: '',
    cim: '',
    idopont: '',
    letszam: '',
    oraszam: '',
    kategoria: '',
    leiras: '',
    statusz: ''
  });

  useEffect(() => {
    const fetchJobData = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`https://localhost:7259/api/Munka/${id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        const data = response.data;
        const dateObj = new Date(data.idopont);
        const localIso = new Date(dateObj.getTime() - (dateObj.getTimezoneOffset() * 60000)).toISOString().slice(0, 16);

        setJobData({
          munka_nev: data.munka_nev,
          cim: data.cim,
          idopont: localIso,
          letszam: data.letszam,
          oraszam: data.oraszam,
          kategoria: data.kategoria,
          leiras: data.leiras,
          statusz: data.statusz
        });
      } catch (error) {
        console.error("Hiba a munka betöltésekor:", error);
        toast.error("Nem sikerült betölteni a hirdetés adatait.");
        navigate('/ceg-profil');
      } finally {
        setFetching(false);
      }
    };
    fetchJobData();
  }, [id, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setJobData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const ceg_id = localStorage.getItem('userId');
    const token = localStorage.getItem('token');

    try {
      await axios.put(`https://localhost:7259/api/Munka/${id}`, {
        munka_id: parseInt(id),
        munka_nev: jobData.munka_nev,
        cim: jobData.cim,
        idopont: jobData.idopont,
        oraszam: parseInt(jobData.oraszam),
        letszam: parseInt(jobData.letszam),
        leiras: jobData.leiras,
        kategoria: jobData.kategoria,
        ceg_id: parseInt(ceg_id),
        statusz: jobData.statusz
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success("Hirdetés sikeresen frissítve!");
      navigate('/ceg-profil');
    } catch (error) {
      toast.error("Sikertelen módosítás!");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) return (
    <div className="new-job-page" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ color: 'var(--text-main)', fontSize: '20px' }}>⏳ Adatok betöltése...</div>
    </div>
  );

  return (
    <div className="new-job-page">
      <DynamicNavbar />

      <div className="new-job-container">
        <div className="new-job-header anim-fade-in">
          <button type="button" className="back-btn" onClick={() => navigate('/ceg-profil')}>← Vissza</button>
          <div>
            <div className="breadcrumbs">Portál / <strong>Szerkesztés</strong></div>
            <h1 className="page-title">Hirdetés szerkesztése</h1>
          </div>
        </div>

        <div className="new-job-card anim-fade-in-delayed">
          <form className="new-job-form" onSubmit={handleSubmit}>

            <div className="input-group">
              <label>Pozíció megnevezése *</label>
              <input type="text" name="munka_nev" required value={jobData.munka_nev} onChange={handleInputChange} />
            </div>

            <div className="input-group">
              <label>Munkavégzés helyszíne (Cím) *</label>
              <div className="input-with-icon">
                <span>📍</span>
                <input type="text" name="cim" required value={jobData.cim} onChange={handleInputChange} />
              </div>
            </div>

            <div className="form-row three-cols">
              <div className="input-group">
                <label>Munka időpontja *</label>
                <div className="input-with-icon">
                  <span>📅</span>
                  <input type="datetime-local" name="idopont" required value={jobData.idopont} onChange={handleInputChange} />
                </div>
              </div>
              <div className="input-group">
                <label>Létszám (fő) *</label>
                <input type="number" name="letszam" required min="1" value={jobData.letszam} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Max. Óraszám (fő)*</label>
                <input type="number" name="oraszam" required min="1" max="50" value={jobData.oraszam} onChange={handleInputChange} />
              </div>
            </div>

            <div className="input-group">
              <label>Kategória *</label>
              <div className="radio-group-container">
                {categories.map(cat => (
                  <label key={cat.id} className={`radio-card ${jobData.kategoria === cat.id ? 'selected' : ''}`}>
                    <input type="radio" name="kategoria" value={cat.id} checked={jobData.kategoria === cat.id} onChange={handleInputChange} />
                    <span className="radio-icon">{cat.icon}</span>
                    <span className="radio-text">{cat.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="input-group">
              <label>Részletes leírás és elvárások ismertetése*</label>
              <textarea rows="6" name="leiras" required value={jobData.leiras} onChange={handleInputChange}></textarea>
            </div>

            <div className="input-group">
              <label>Hirdetés státusza</label>
              <select
                name="statusz"
                value={jobData.statusz}
                onChange={handleInputChange}
                style={{
                  width: '100%', padding: '12px', borderRadius: '8px',
                  border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-main)',
                  color: 'var(--text-main)', outline: 'none'
                }}
              >
                <option value="aktiv">Aktív (Látható a diákoknak)</option>
                <option value="lezarva">Lezárva (Nem látható, betelt)</option>
              </select>
            </div>

            <div className="form-actions">
              <button type="button" className="btn-secondary" onClick={() => navigate('/ceg-profil')}>Mégsem</button>
              <button type="submit" className="btn-primary" disabled={loading}>
                {loading ? '⏳ Mentés...' : '💾 Változtatások Mentése'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}