import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './NavbarCompany.css';

export default function NavbarCompany() {
  const navigate = useNavigate();
  const [companyName, setCompanyName] = useState('');

  const [darkMode, setDarkMode] = useState(localStorage.getItem('theme') === 'dark');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const name = localStorage.getItem('userName');
    setCompanyName(name || 'Vállalat');

    if (darkMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('theme', newMode ? 'dark' : 'light');
    if (newMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  };

  const handleNavClick = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="company-navbar">

      <div className="company-left-section">
        <div className="navbar-logo" onClick={() => handleNavClick('/')}>
          <span className="logo-icon">💼</span>
          <span className="logo-text">Ötven óra <span className="logo-badge">CÉGEKNEK</span></span>
        </div>
        <button
          onClick={toggleDarkMode}
          className="guest-theme-toggle"
          title={darkMode ? "Világos mód bekapcsolása" : "Sötét mód bekapcsolása"}
        >
          {darkMode ? '☀️' : '🌙'}
        </button>
      </div>

      <button
        className="navbar-hamburger"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        style={{ color: 'var(--text-main)' }}
      >
        {isMobileMenuOpen ? (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        ) : (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        )}
      </button>

      <div className={`company-right-section ${isMobileMenuOpen ? 'open' : ''}`}>

        <div className="navbar-links">
          <span onClick={() => handleNavClick('/uj-hirdetes')} className="nav-link highlight-link" style={{ cursor: 'pointer' }}>+ Új hirdetés</span>
          <span onClick={() => handleNavClick('/ceg-profil?tab=jelentkezok')} className="nav-link" style={{ cursor: 'pointer' }}>Jelentkezők</span>
        </div>

        <div className="navbar-profile-section">
          <span className="company-name-text">{companyName}</span>
          <div onClick={() => handleNavClick('/ceg-profil')} className="company-profile-icon" title="Cégadatok szerkesztése">
            🏢
          </div>
        </div>

      </div>
    </nav>
  );
}