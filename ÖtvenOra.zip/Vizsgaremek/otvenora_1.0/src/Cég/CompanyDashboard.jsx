import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import DynamicNavbar from '../Other/DynamicNavbar';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import SignatureCanvas from 'react-signature-canvas';
import { useRef } from 'react';
import { useToast } from '../Other/ToastContext';
import './CompanyDashboard.css';

export default function CompanyDashboard() {
  const navigate = useNavigate();
  const toast = useToast();

  const [activeTab, setActiveTab] = useState('profil');
  const [isSaving, setIsSaving] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [companyData, setCompanyData] = useState({
    cegnev: localStorage.getItem('userName') || 'Betöltés...',
    ceg_email: '', cim: '', adoszam: '', telefonszam: '',
    weboldal: 'Nincs megadva weboldal', bemutatkozas: 'Nincs megadva bemutatkozás.'
  });
  const [allMyJobs, setAllMyJobs] = useState([]);
  const [jelentkezok, setJelentkezok] = useState([]);
  const [editModalData, setEditModalData] = useState(null);
  const [confirmModalData, setConfirmModalData] = useState(null);

  const [completeModalData, setCompleteModalData] = useState(null);
  const [hoursFormat, setHoursFormat] = useState('');
  const [hoursError, setHoursError] = useState('');
  const sigCanvasRef = useRef(null);
  const [startDate, setStartDate] = useState('');

  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [settingsTab, setSettingsTab] = useState('megjelenes');
  const [darkMode, setDarkMode] = useState(localStorage.getItem('theme') === 'dark');

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordData, setPasswordData] = useState({ regi: '', uj: '', ujMegerosites: '' });
  const [passwordError, setPasswordError] = useState('');
  const [isPasswordSaving, setIsPasswordSaving] = useState(false);

  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('tab') === 'jelentkezok') {
      setActiveTab('jelentkezok');
    }
  }, [location]);

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
    setIsMobileMenuOpen(false);
  };

  useEffect(() => {
    if (darkMode) document.body.classList.add('dark-theme');
    else document.body.classList.remove('dark-theme');
  }, [darkMode]);

  useEffect(() => {
    const fetchData = async () => {
      const userId = localStorage.getItem('userId');
      const token = localStorage.getItem('token');

      if (!userId) return;

      try {
        const cegResponse = await axios.get(`https://localhost:7259/api/Ceg/${userId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (cegResponse.data) {
          setCompanyData(prev => ({
            ...prev,
            cegnev: cegResponse.data.cegnev || cegResponse.data.Cegnev || prev.cegnev,
            ceg_email: cegResponse.data.ceg_email || cegResponse.data.cegEmail || prev.ceg_email,
            cim: cegResponse.data.cim || cegResponse.data.Cim || prev.cim,
            adoszam: cegResponse.data.adoszam || cegResponse.data.Adoszam || prev.adoszam,
            telefonszam: cegResponse.data.telefonszam || cegResponse.data.Telefonszam || prev.telefonszam
          }));
        }

        const munkaResponse = await axios.get(`https://localhost:7259/api/Munka`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (munkaResponse.data) {
          const myJobs = munkaResponse.data.filter(job => job.ceg_id === parseInt(userId));
          setAllMyJobs(myJobs.reverse());

          try {
            const jelResponse = await axios.get(`https://localhost:7259/api/Jelentkezes`, {
              headers: { Authorization: `Bearer ${token}` }
            });
            if (jelResponse.data) {
              const myJobIds = myJobs.map(j => j.munka_id);
              const myJelentkezesek = jelResponse.data.filter(jel => myJobIds.includes(jel.munka_id));
              setJelentkezok(myJelentkezesek.reverse());
            }
          } catch (err) {
            console.error("Nem sikerült lekérni a jelentkezőket:", err);
          }
        }
      } catch (error) {
        console.error("Hiba az adatok lekérésekor:", error);
      }
    };
    fetchData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCompanyData(prev => ({ ...prev, [name]: value }));
  };

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = '/';
  };

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('theme', newMode ? 'dark' : 'light');
    if (newMode) document.body.classList.add('dark-theme');
    else document.body.classList.remove('dark-theme');
  };

  const handleSaveCompanyData = async () => {
    setIsSaving(true);
    const userId = localStorage.getItem('userId');
    const token = localStorage.getItem('token');

    try {
      await axios.put(`https://localhost:7259/api/Ceg/${userId}`, {
        ceg_id: parseInt(userId),
        cegnev: companyData.cegnev,
        ceg_email: companyData.ceg_email,
        cim: companyData.cim,
        adoszam: companyData.adoszam,
        telefonszam: companyData.telefonszam,
        jelszo: "kikeruljuk_a_csharp_ellenorzest"
      }, { headers: { Authorization: `Bearer ${token}` } });

      localStorage.setItem('userName', companyData.cegnev);
      toast.success('Cégadatok sikeresen frissítve!');
    } catch (error) {
      toast.error('Hiba történt a mentés során!');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePasswordInputChange = (e) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
    setPasswordError('');
  };

  const isLengthValid = passwordData.uj.length >= 8;
  const isLowerUpperValid = /(?=.*[a-z])(?=.*[A-Z])/.test(passwordData.uj);
  const isNumberValid = /(?=.*\d)/.test(passwordData.uj);
  const isSpecialValid = /(?=.*[@#$%!?&_.\-])/.test(passwordData.uj);
  const isPasswordStrongEnough = isLengthValid && isLowerUpperValid && isNumberValid && isSpecialValid;

  const handleSubmitPasswordChange = async () => {
    if (!passwordData.regi || !passwordData.uj || !passwordData.ujMegerosites) { setPasswordError('Minden mezőt ki kell tölteni!'); return; }
    if (passwordData.uj === passwordData.regi) { setPasswordError('Az új jelszó nem lehet ugyanaz, mint a régi!'); return; }
    if (passwordData.uj !== passwordData.ujMegerosites) { setPasswordError('A két új jelszó nem egyezik!'); return; }
    if (!isPasswordStrongEnough) { setPasswordError('Az új jelszó nem felel meg a biztonsági követelményeknek!'); return; }

    setIsPasswordSaving(true);
    try {
      const userId = localStorage.getItem('userId');
      const token = localStorage.getItem('token');
      await axios.put(`https://localhost:7259/api/Ceg/jelszo/${userId}`, {
        RegiJelszo: passwordData.regi.trim(), UjJelszo: passwordData.uj.trim()
      }, { headers: { Authorization: `Bearer ${token}` } });

      toast.success("Jelszó sikeresen módosítva!");
      setShowPasswordModal(false);
      setPasswordData({ regi: '', uj: '', ujMegerosites: '' });
    } catch (error) {
      setPasswordError(error.response?.data?.message || 'Hiba történt a jelszó módosításakor!');
    } finally { setIsPasswordSaving(false); }
  };

  const handleDeleteAccount = async () => {
    const isConfirmed = window.confirm("⚠️ VIGYÁZAT! Biztosan véglegesen törölni szeretné a céges fiókot?");
    if (isConfirmed) {
      try {
        const userId = localStorage.getItem('userId');
        const token = localStorage.getItem('token');
        await axios.delete(`https://localhost:7259/api/Ceg/${userId}`, { headers: { Authorization: `Bearer ${token}` } });
        toast.success("A fiókot sikeresen töröltük.");
        localStorage.clear(); navigate('/');
      } catch (error) { toast.error("Hiba történt a törlés során!"); }
    }
  };

  const closeModals = () => {
    setEditModalData(null);
    setConfirmModalData(null);
    setCompleteModalData(null);
    setHoursFormat('');
    setHoursError('');
  };

  const openEditModal = (jelentkezes) => setEditModalData(jelentkezes);

  const initiateStatusChange = (munkaId, diakId, ujStatusz) => {
    if (ujStatusz.toLowerCase() === 'teljesítve') {
      setCompleteModalData({ munkaId, diakId });
    } else if (ujStatusz.toLowerCase() === 'elutasítva') {
      setConfirmModalData({ munkaId, diakId, ujStatusz });
    } else {
      handleUpdateApplicationStatus(munkaId, diakId, ujStatusz);
      closeModals();
    }
  };

  const confirmStatusChange = () => {
    if (confirmModalData) {
      handleUpdateApplicationStatus(confirmModalData.munkaId, confirmModalData.diakId, confirmModalData.ujStatusz);
      closeModals();
    }
  };

  const handleUpdateApplicationStatus = async (munkaId, diakId, ujStatusz, jovahagyottOra = 0, documentRecipe = null) => {
    try {
      const token = localStorage.getItem('token');

      const payload = { ujStatusz: ujStatusz };
      if (ujStatusz.toLowerCase() === 'teljesítve') {
        payload.JovahagyottOra = jovahagyottOra;
        if (documentRecipe) {
          payload.IgazolasAdatok = JSON.stringify(documentRecipe);
        }
      }

      await axios.put(`https://localhost:7259/api/Jelentkezes/statusz/${munkaId}/${diakId}`,
        payload,
        { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } }
      );

      setJelentkezok(prev => prev.map(jel =>
        (jel.munka_id === munkaId && jel.diak_id === diakId) ? { ...jel, munka_statusz: ujStatusz } : jel
      ));

      let uzenet = ujStatusz;
      if (ujStatusz === 'folyamatban') uzenet = 'elfogadva (folyamatban)';
      if (ujStatusz === 'elutasítva') uzenet = 'elutasítva';
      if (ujStatusz === 'teljesítve') uzenet = 'teljesítveként megjelölve';

      if (ujStatusz !== 'teljesítve') toast.success(`Jelentkezés ${uzenet}!`);
    } catch (error) {
      toast.error("Nem sikerült frissíteni a státuszt.");
      throw error;
    }
  };

  const validateHours = (format) => {
    if (!format) return "Kérlek add meg az óraszámot!";
    const parts = format.split('*');
    if (parts.length !== 2) return "Hibás formátum! Használj 'nap*óra' formátumot (pl. 3*5).";

    const days = parseInt(parts[0].trim(), 10);
    const hours = parseInt(parts[1].trim(), 10);

    if (isNaN(days) || isNaN(hours)) return "Csak számokat használj a formátumban!";
    if (days <= 0 || hours <= 0) return "A napok és órák száma nagyobb kell legyen 0-nál!";
    if (hours > 5) return "Maximum napi 5 óra adható meg!";

    return "";
  };

  const handleIssueDocument = async () => {
    const errorMsg = validateHours(hoursFormat);
    if (errorMsg) { setHoursError(errorMsg); return; }
    if (sigCanvasRef.current.isEmpty()) { setHoursError("Kérlek írd alá az igazolást a vásznon!"); return; }

    setHoursError('');

    const parts = hoursFormat.split('*');
    const days = parseInt(parts[0].trim(), 10);
    const hours = parseInt(parts[1].trim(), 10);
    const totalAddedHours = days * hours;

    const { munkaId, diakId } = completeModalData;
    const token = localStorage.getItem('token');

    const aktualisJelentkezes = jelentkezok.find(j => j.munka_id === munkaId && j.diak_id === diakId);
    const diakNeve = aktualisJelentkezes?.diak?.nev || aktualisJelentkezes?.Diak?.Nev || "Ismeretlen Diák";
    const aktualisMunka = allMyJobs.find(m => m.munka_id === munkaId);

    let rawDate = aktualisMunka?.idopont || aktualisMunka?.Datum || aktualisMunka?.kezdodatum || aktualisMunka?.Kezdodatum || new Date().toISOString();
    const autoStartDate = rawDate.split('T')[0].split(' ')[0];

    const signatureImage = sigCanvasRef.current.getCanvas().toDataURL('image/png');

    const documentRecipe = {
      formatum: hoursFormat,
      kezdodatum: autoStartDate,
      ceg_nev: companyData.cegnev,
      diak_neve: diakNeve,
      munka_nev: aktualisMunka?.munka_nev || "Közösségi munka",
      kategoria: aktualisMunka?.kategoria || "Általános",
      alairas_base64: signatureImage
    };

    try {
      await axios.put(`https://localhost:7259/api/Diak/orak/${diakId}`, {
        HozzaadottOrak: totalAddedHours
      }, { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } });

      await handleUpdateApplicationStatus(munkaId, diakId, 'teljesítve', totalAddedHours, documentRecipe);

      toast.success(`Dokumentum sikeresen kiállítva és aláírva!`);
      closeModals();
    } catch (error) {
      console.error("Hiba az igazolás kiállításakor:", error);
      toast.error("Hiba történt a mentés során!");
    }
  };

  const clearSignature = () => {
    if (sigCanvasRef.current) sigCanvasRef.current.clear();
  };

  const handleDeleteJob = async (jobId) => {
    if (window.confirm('Biztosan véglegesen törölni szeretnéd ezt a hirdetést? Ezt nem lehet visszavonni!')) {
      try {
        const token = localStorage.getItem('token');
        await axios.delete(`https://localhost:7259/api/Munka/${jobId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setAllMyJobs(prevJobs => prevJobs.filter(job => job.munka_id !== jobId));
        toast.success('Hirdetés sikeresen törölve!');
      } catch (error) {
        toast.error('Hiba történt a törlés során!');
      }
    }
  };

  const handlePreviewDocument = (jelentkezes) => {
    try {
      const recipeStr = jelentkezes.igazolas_adatok || jelentkezes.Igazolas_adatok || jelentkezes.IgazolasAdatok;
      if (!recipeStr) {
        toast.error("Ehhez a munkához még nem készült el a digitális igazolás!");
        return;
      }
      const recipe = JSON.parse(recipeStr);

      const doc = new jsPDF();
      const normalizeHu = (text) => text?.toString().replace(/ő/g, 'ö').replace(/ű/g, 'ü').replace(/Ő/g, 'Ö').replace(/Ű/g, 'Ü') || '';

      doc.setFontSize(14);
      doc.setFont("helvetica", "bolditalic");
      doc.setTextColor(34, 139, 34);
      doc.text("ÖTVEN ÓRA", 14, 25);
      doc.setTextColor(0);

      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text(normalizeHu("KÖZÖSSÉGI SZOLGÁLATI NAPLÓ - ELŐNÉZET"), 105, 30, { align: "center" });

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");

      doc.text(`Tanuló neve: ${normalizeHu(recipe.diak_neve)}`, 14, 45);
      doc.text(`Osztálya: [DIÁK TÖLTI KI]`, 95, 45);
      doc.text(`Oktatási azonosítója: [DIÁK TÖLTI KI]`, 145, 45);
      doc.text(`Iskola OM kódja: [DIÁK TÖLTI KI]`, 14, 55);
      doc.text(`Iskola neve: [DIÁK TÖLTI KI]`, 95, 55);

      const tableBody = [];
      const [daysStr, hoursStr] = recipe.formatum.split('*');
      const totalDays = parseInt(daysStr, 10);
      const hoursPerDay = parseInt(hoursStr, 10);

      let currentDate = new Date(recipe.kezdodatum);

      for (let i = 0; i < totalDays; i++) {
        const dateString = `${currentDate.getFullYear()}.${String(currentDate.getMonth() + 1).padStart(2, '0')}.${String(currentDate.getDate()).padStart(2, '0')}.`;
        tableBody.push([
          dateString,
          hoursPerDay.toString(),
          normalizeHu(`${recipe.kategoria} - ${recipe.munka_nev}, ${recipe.leiras || 'Nincs részletes leírás.'}`),
          "",
          normalizeHu(recipe.ceg_nev)
        ]);
        currentDate.setDate(currentDate.getDate() + 1);
      }

      autoTable(doc, {
        startY: 65,
        head: [['Dátum', 'Teljesített\nóra', 'Feladat(ok)\nleírása', 'Tanácsadó-mentor\naláírása', 'Fogadó cég neve']],
        body: tableBody,
        theme: 'grid',
        headStyles: { fillColor: [255, 255, 255], textColor: [0, 0, 0], lineColor: [34, 139, 34], lineWidth: 0.5, halign: 'center', fontStyle: 'bold' },
        bodyStyles: { lineColor: [34, 139, 34], lineWidth: 0.5, minCellHeight: 25, valign: 'middle' },
        columnStyles: { 0: { cellWidth: 25 }, 1: { cellWidth: 25, halign: 'center' }, 2: { cellWidth: 'auto' }, 3: { cellWidth: 35 }, 4: { cellWidth: 35 } },
        didDrawCell: function (data) {
          if (data.column.index === 3 && data.section === 'body') {
            doc.addImage(recipe.alairas_base64, 'PNG', data.cell.x + 2, data.cell.y + 2, 30, 10);
          }
        }
      });

      const finalY = doc.lastAutoTable.finalY + 15;

      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.text(normalizeHu(`Összes óra: ${totalDays * hoursPerDay}`), 14, finalY);

      doc.setFont("helvetica", "normal");
      const today = new Date();
      const todayStr = `${today.getFullYear()}.${String(today.getMonth() + 1).padStart(2, '0')}.${String(today.getDate()).padStart(2, '0')}.`;
      doc.text(normalizeHu(`Lezárva (dátum): ${todayStr}`), 135, finalY);

      const authCode = `OTVEN-ELONEZET-${Math.floor(Math.random() * 10000)}`;
      doc.setFontSize(8);
      doc.setTextColor(120);
      doc.text(normalizeHu(`Elektronikusan generált előnézet. Azonosító: ${authCode}`), 14, 285);

      doc.save(`Elonezet_${normalizeHu(recipe.diak_neve)}.pdf`);
    } catch (err) {
      console.error(err);
      toast.error("Hiba az előnézet generálásakor.");
    }
  };

  const fuggobenCount = jelentkezok.filter(j =>
    j.munka_statusz?.toLowerCase() === 'elküldve'
  ).length;

  const fogadottDiakokCount = new Set(
    jelentkezok
      .filter(j => {
        const s = j.munka_statusz?.toLowerCase();
        return s !== 'elküldve' && s !== 'elutasítva';
      })
      .map(j => j.diak_id)
  ).size;

  const aktivHirdetesekCount = allMyJobs.filter(j =>
    j.statusz?.toLowerCase() === 'aktiv'
  ).length;

  const renderContent = () => {
    switch (activeTab) {
      case 'profil':
        return (
          <>
            <section className="stats-row">
              <div className="dash-anim-wrapper">
                <div className="stat-card hover-card">
                  <div className="stat-header">
                    <h3>Függőben lévő jelentkezések</h3>
                    <div className="stat-icon blue-icon">🕒</div>
                  </div>
                  <div className="stat-value"><strong>{fuggobenCount}</strong> <span>diák</span></div>
                </div>
              </div>
              <div className="dash-anim-wrapper">
                <div className="stat-card hover-card">
                  <div className="stat-header">
                    <h3>Fogadott diákok</h3>
                    <div className="stat-icon blue-icon">🎓</div>
                  </div>
                  <div className="stat-value"><strong>{fogadottDiakokCount}</strong> <span>fő</span></div>
                </div>
              </div>
              <div className="dash-anim-wrapper">
                <div className="stat-card hover-card">
                  <div className="stat-header">
                    <h3>Aktív hirdetések</h3>
                    <div className="stat-icon blue-icon">📢</div>
                  </div>
                  <div className="stat-value"><strong>{aktivHirdetesekCount}</strong> <span>aktív</span></div>
                </div>
              </div>
            </section>

            <section className="dashboard-grid">
              <div className="dash-anim-wrapper">
                <div className="edit-profile-card hover-card">
                  <div className="card-header">
                    <h2>🏢 Cégadatok</h2>
                  </div>
                  <form className="edit-form">
                    <div className="form-row">
                      <div className="input-group">
                        <label>Cégnév</label>
                        <input type="text" name="cegnev" value={companyData.cegnev} onChange={handleInputChange} />
                      </div>
                      <div className="input-group">
                        <label>Cégjegyzékszám / Adószám</label>
                        <input type="text" name="adoszam" value={companyData.adoszam} onChange={handleInputChange} />
                      </div>
                    </div>
                    <div className="input-group">
                      <label>Székhely Címe</label>
                      <div className="input-with-icon">
                        <span>📍</span>
                        <input type="text" name="cim" value={companyData.cim} onChange={handleInputChange} />
                      </div>
                    </div>
                    <div className="form-row">
                      <div className="input-group">
                        <label>Telefonszám</label>
                        <div className="input-with-icon">
                          <span>📞</span>
                          <input type="text" name="telefonszam" value={companyData.telefonszam} onChange={handleInputChange} />
                        </div>
                      </div>
                      <div className="input-group">
                        <label>Kapcsolattartó Email</label>
                        <input type="email" name="ceg_email" value={companyData.ceg_email} onChange={handleInputChange} />
                      </div>
                    </div>
                    <div className="form-actions">
                      <button type="button" className="btn-primary" onClick={handleSaveCompanyData} disabled={isSaving}>
                        {isSaving ? '⏳ Mentés...' : '💾 Változtatások mentése'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>

              <div className="right-column">
                <div className="dash-anim-wrapper">
                  <div className="quick-post-card hover-card">
                    <div className="card-header">
                      <div>
                        <h2>Új munka</h2>
                        <p>Hozzon létre egy új lehetőséget.</p>
                      </div>
                      <button className="add-icon-btn" onClick={() => navigate('/uj-hirdetes')}>+</button>
                    </div>
                    <div className="quick-post-form">
                      <button className="btn-primary full-width" onClick={() => navigate('/uj-hirdetes')}>
                        + Űrlap megnyitása
                      </button>
                    </div>
                  </div>
                </div>

                <div className="dash-anim-wrapper">
                  <div className="active-jobs-card hover-card">
                    <div className="card-header">
                      <h2>Legújabb munkák</h2>
                      <span className="text-link" onClick={() => handleTabClick('munkaim')}>Összes</span>
                    </div>
                    <div className="job-list">
                      {allMyJobs.slice(0, 2).map((job) => (
                        <div className="job-item" key={job.munka_id}>
                          <div className="job-item-header">
                            <h4>{job.munka_nev}</h4>
                            <span className={`job-status ${job.statusz?.toLowerCase() === 'aktiv' ? 'green' : 'yellow'}`}>
                              {job.statusz || 'Aktív'}
                            </span>
                          </div>
                          <div className="job-details-mini">
                            <span>👥 {jelentkezok.filter(jel => jel.munka_id === job.munka_id).length}/{job.letszam} jelentkező</span>
                            <span>🕒 Max. {job.oraszam} óra</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </>
        );

      case 'munkaim':
        return (
          <div className="dash-anim-wrapper">
            <div className="edit-profile-card hover-card" style={{ padding: '30px' }}>
              <div className="card-header" style={{ marginBottom: '20px' }}>
                <h2>💼 Összes meghirdetett munkám</h2>
                <button className="btn-primary" onClick={() => navigate('/uj-hirdetes')}>+ Új</button>
              </div>
              <div className="job-list">
                {allMyJobs.map((job) => (
                  <div className="job-item" key={job.munka_id} style={{ marginBottom: '15px' }}>
                    <div className="job-item-header">
                      <div>
                        <h4 style={{ fontSize: '18px' }}>{job.munka_nev}</h4>
                        <span className="job-date">Helyszín: {job.cim}</span>
                      </div>
                      <span className={`job-status ${job.statusz?.toLowerCase() === 'aktiv' ? 'green' : 'yellow'}`}>
                        {job.statusz || 'Aktív'}
                      </span>
                    </div>
                    <div className="job-details-mini" style={{ marginTop: '10px' }}>
                      <span>👥 {jelentkezok.filter(jel => jel.munka_id === job.munka_id).length}/{job.letszam} jelentkező</span>
                      <span>🕒 Max. {job.oraszam} óra</span>
                    </div>
                    <div className="job-actions" style={{ marginTop: '15px' }}>
                      <button className="btn-outline" onClick={() => navigate(`/munka-szerkesztes/${job.munka_id}`)}>Szerkesztés</button>
                      <button className="btn-outline" style={{ color: '#ef4444', borderColor: '#fca5a5' }} onClick={() => handleDeleteJob(job.munka_id)}>Törlés</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'jelentkezok':
        return (
          <div className="dash-anim-wrapper">
            <div className="edit-profile-card hover-card" style={{ padding: '30px' }}>
              <div className="card-header" style={{ marginBottom: '20px' }}>
                <h2>👥 Jelentkezők kezelése</h2>
              </div>
              <div className="table-responsive" style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                  <thead>
                    <tr style={{ borderBottom: '2px solid var(--border-color)', color: 'var(--text-muted)' }}>
                      <th style={{ padding: '12px' }}>Diák neve</th>
                      <th style={{ padding: '12px' }}>Munka</th>
                      <th style={{ padding: '12px' }}>Státusz</th>
                      <th style={{ padding: '12px' }}>Műveletek</th>
                    </tr>
                  </thead>
                  <tbody>
                    {jelentkezok.length === 0 ? (
                      <tr><td colSpan="4" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>Nincs jelentkező.</td></tr>
                    ) : (
                      jelentkezok.map((jel, index) => {
                        const job = allMyJobs.find(m => m.munka_id === jel.munka_id);
                        return (
                          <tr key={index} style={{ borderBottom: '1px solid var(--border-color)' }}>
                            <td style={{ padding: '16px 12px', color: 'var(--text-main)' }}>
                              👤 {jel.diak?.nev || jel.Diak?.Nev || `Diák #${jel.diak_id}`}
                            </td>
                            <td style={{ padding: '16px 12px', color: 'var(--text-main)' }}>
                              {job?.munka_nev || '...'}
                            </td>
                            <td style={{ padding: '16px 12px' }}>
                              <span className={`status-badge ${jel.munka_statusz?.toLowerCase() === 'elfogadva' || jel.munka_statusz?.toLowerCase() === 'teljesítve' ? 'green'
                                : jel.munka_statusz?.toLowerCase() === 'elutasítva' ? 'red'
                                  : 'yellow'
                                }`}>
                                {jel.munka_statusz}
                              </span>
                            </td>
                            <td style={{ padding: '16px 12px' }}>
                              {jel.munka_statusz?.toLowerCase() === 'elküldve' ? (
                                <div style={{ display: 'flex', gap: '8px' }}>
                                  <button className="btn-primary" style={{ padding: '6px 10px', fontSize: '12px' }} onClick={() => initiateStatusChange(jel.munka_id, jel.diak_id, 'elfogadva')}>Jóváhagyás</button>
                                  <button className="btn-outline" style={{ padding: '6px 10px', fontSize: '12px', color: '#ef4444', borderColor: '#fca5a5' }} onClick={() => initiateStatusChange(jel.munka_id, jel.diak_id, 'elutasítva')}>Elutasítás</button>
                                </div>
                              ) : jel.munka_statusz?.toLowerCase() === 'teljesítve' ? (
                                <button
                                  className="btn-primary"
                                  style={{ padding: '6px 12px', fontSize: '12px', backgroundColor: '#10b981', borderColor: '#10b981' }}
                                  onClick={() => handlePreviewDocument(jel)}
                                >
                                  📄 Dokumentum Előnézete
                                </button>
                              ) : (
                                <button className="btn-outline" style={{ padding: '6px 12px', fontSize: '12px', color: 'var(--text-main)', borderColor: 'var(--border-color)', fontWeight: '600' }} onClick={() => openEditModal(jel)}>Szerkesztés</button>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      default: return null;
    }
  };

  return (
    <div className="company-dashboard-page">
      <DynamicNavbar />

      <div className="mobile-header">
        <div className="mobile-brand">
          <span className="brand-icon">🏢</span>
          <h2>Céges Panel</h2>
        </div>
        <button className="hamburger-btn" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? '✕' : '☰'}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="sidebar-overlay" onClick={() => setIsMobileMenuOpen(false)}></div>
      )}

      <div className="company-dashboard-container">

        <aside className={`company-sidebar ${isMobileMenuOpen ? 'open' : ''}`}>

          <button
            className="sidebar-close-btn"
            onClick={() => setIsMobileMenuOpen(false)}
            style={{ position: 'absolute', top: '20px', right: '20px', background: 'none', border: 'none', fontSize: '24px', color: 'var(--text-muted)', cursor: 'pointer', zIndex: 10 }}
          >
            ✕
          </button>

          <div className="sidebar-menu">
            <button className={`sidebar-btn ${activeTab === 'profil' ? 'active' : ''}`} onClick={() => handleTabClick('profil')}><span className="icon">👤</span> Profil</button>
            <button className={`sidebar-btn ${activeTab === 'munkaim' ? 'active' : ''}`} onClick={() => handleTabClick('munkaim')}><span className="icon">💼</span> Munkáim</button>
            <button className={`sidebar-btn ${activeTab === 'jelentkezok' ? 'active' : ''}`} onClick={() => handleTabClick('jelentkezok')}><span className="icon">👥</span> Jelentkezők <span className="badge-count">{fuggobenCount}</span></button>
            <button className="sidebar-btn" onClick={() => navigate('/uj-hirdetes')}><span className="icon">📝</span> Új hirdetés</button>

            <button className="sidebar-btn" onClick={() => { navigate('/'); setIsMobileMenuOpen(false); }}>
              <span className="icon">🏠</span> Főoldal
            </button>

            <button className="sidebar-btn" onClick={() => { setShowSettingsModal(true); setIsMobileMenuOpen(false); setSettingsTab('megjelenes'); }}><span className="icon">⚙️</span> Beállítások</button>
          </div>
          <div className="sidebar-bottom">
            <div className="sidebar-user-info">
              <div className="user-avatar">🏢</div>
              <div className="user-details"><strong>{companyData.cegnev}</strong><span>{companyData.ceg_email}</span></div>
            </div>
            <button className="sidebar-logout-btn" onClick={handleLogout}><span className="icon">🚪</span> Kijelentkezés</button>
          </div>
        </aside>

        <main className="company-main-content">
          <header className="main-header desktop-only">
            <div className="breadcrumbs">Portál / <strong>{activeTab}</strong></div>
            <h1>Üdvözöljük, {companyData.cegnev}</h1>
          </header>
          {renderContent()}
        </main>
      </div>

      {showSettingsModal && (
        <div className="custom-modal-overlay" onClick={() => setShowSettingsModal(false)} style={{ backdropFilter: 'blur(8px)', backgroundColor: 'rgba(0, 0, 0, 0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div className="custom-modal-box settings-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '1000px', width: '90%', height: '700px', padding: 0, borderRadius: '16px', display: 'flex', overflow: 'hidden', position: 'relative', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>

            <div className="settings-sidebar" style={{ width: '260px', borderRight: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', paddingTop: '30px', backgroundColor: 'var(--bg-main)' }}>
              <h2 style={{ fontSize: '20px', padding: '0 20px', marginBottom: '20px', color: 'var(--text-main)' }}>⚙️ Beállítások</h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <button className={`settings-nav-btn ${settingsTab === 'megjelenes' ? 'active' : ''}`} onClick={() => setSettingsTab('megjelenes')}>🎨 Megjelenés</button>
                <button className={`settings-nav-btn ${settingsTab === 'adatok' ? 'active' : ''}`} onClick={() => setSettingsTab('adatok')}>🔒 Biztonság</button>
                <button className={`settings-nav-btn danger ${settingsTab === 'fiok' ? 'active' : ''}`} onClick={() => setSettingsTab('fiok')}>🗑️ Fiókbeállítások</button>
              </div>
            </div>

            <div className="settings-content" style={{ flex: 1, padding: '40px', position: 'relative', overflowY: 'auto', backgroundColor: 'var(--bg-card)' }}>
              <button className="settings-close-btn" onClick={() => setShowSettingsModal(false)} style={{ position: 'absolute', top: '20px', right: '25px', border: 'none', width: '36px', height: '36px', borderRadius: '50%', fontSize: '16px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'var(--bg-main)', color: 'var(--text-muted)' }}>✖</button>
              <div key={settingsTab} className="tab-content-anim">

                {settingsTab === 'megjelenes' && (
                  <div>
                    <h3 style={{ fontSize: '22px', marginBottom: '25px', borderBottom: '2px solid var(--border-color)', paddingBottom: '10px', color: 'var(--text-main)' }}>Megjelenés</h3>
                    <div className="settings-inner-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-main)' }}>
                      <div><strong style={{ display: 'block', fontSize: '16px', color: 'var(--text-main)' }}>Sötét mód (Dark Mode)</strong><span style={{ fontSize: '14px', color: 'var(--text-muted)' }}>Kíméletesebb a szemnek esti munkavégzéskor.</span></div>
                      <button onClick={toggleDarkMode} className="theme-toggle-btn" style={{ padding: '10px 20px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', borderRadius: '30px', cursor: 'pointer', fontWeight: 'bold', transition: 'all 0.3s' }}>{darkMode ? '🌙 Bekapcsolva' : '☀️ Kikapcsolva'}</button>
                    </div>
                  </div>
                )}

                {settingsTab === 'adatok' && (
                  <div>
                    <h3 style={{ fontSize: '22px', marginBottom: '25px', borderBottom: '2px solid var(--border-color)', paddingBottom: '10px', color: 'var(--text-main)' }}>Biztonság és Jelszó</h3>
                    <p style={{ color: 'var(--text-muted)', marginBottom: '20px' }}>A cégadatok szerkesztését a bal oldali "Profil" fülön találod.</p>
                    <div className="settings-inner-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-main)' }}>
                      <div><strong style={{ display: 'block', fontSize: '16px', color: 'var(--text-main)' }}>Jelszó módosítása</strong><span style={{ fontSize: '14px', color: 'var(--text-muted)' }}>A céges fiók biztonsága érdekében.</span></div>
                      <button onClick={() => setShowPasswordModal(true)} style={{ alignContent: 'center', justifyContent: 'center', alignSelf: 'center', padding: '10px 20px', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px', backgroundColor: 'var(--bg-card)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }}>🔑 Új jelszó kérése</button>
                    </div>
                  </div>
                )}

                {settingsTab === 'fiok' && (
                  <div>
                    <h3 style={{ fontSize: '22px', marginBottom: '25px', borderBottom: '2px solid var(--border-color)', paddingBottom: '10px', color: 'var(--text-main)' }}>Fiókbeállítások</h3>

                    <div className="settings-danger-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '25px', borderRadius: '12px', backgroundColor: 'var(--danger-bg)', border: '1px solid var(--danger-border)' }}>
                      <div><strong style={{ display: 'block', color: 'var(--danger-color)', fontSize: '16px' }}>Céges fiók végleges törlése</strong><span style={{ fontSize: '14px', color: 'var(--danger-color)' }}>Minden hirdetés és adat elvész.</span></div>
                      <button onClick={handleDeleteAccount} style={{ padding: '12px 24px', backgroundColor: 'var(--danger-color)', color: '#ffffff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '15px' }}>🗑️ Fiók törlése</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {showPasswordModal && (
        <div className="custom-modal-overlay" onClick={() => setShowPasswordModal(false)} style={{ zIndex: 1050, backdropFilter: 'blur(3px)', backgroundColor: 'rgba(0, 0, 0, 0.6)' }}>
          <div className="custom-modal-box base-card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '400px', width: '90%', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', padding: '25px', borderRadius: '12px' }}>
            <h2 style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '10px', marginBottom: '20px', color: 'var(--text-main)' }}>Jelszó módosítása</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
              <div><label style={{ display: 'block', fontSize: '13px', fontWeight: 'bold', marginBottom: '5px', color: 'var(--text-muted)' }}>Régi jelszó</label><input type="password" name="regi" value={passwordData.regi} onChange={handlePasswordInputChange} style={{ width: '100%', padding: '10px', borderRadius: '6px', outline: 'none', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
              <div><label style={{ display: 'block', fontSize: '13px', fontWeight: 'bold', marginBottom: '5px', color: 'var(--text-muted)' }}>Új jelszó</label><input type="password" name="uj" value={passwordData.uj} onChange={handlePasswordInputChange} style={{ width: '100%', padding: '10px', borderRadius: '6px', outline: 'none', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
              <div><label style={{ display: 'block', fontSize: '13px', fontWeight: 'bold', marginBottom: '5px', color: 'var(--text-muted)' }}>Új jelszó még egyszer</label><input type="password" name="ujMegerosites" value={passwordData.ujMegerosites} onChange={handlePasswordInputChange} style={{ width: '100%', padding: '10px', borderRadius: '6px', outline: 'none', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }} /></div>
              {passwordError && <div style={{ fontSize: '13px', color: 'var(--danger-color)', fontWeight: 'bold', textAlign: 'center', marginTop: '5px' }}>❌ {passwordError}</div>}
              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button onClick={() => setShowPasswordModal(false)} style={{ flex: 1, padding: '10px', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: '1px solid var(--border-color)' }}>Mégse</button>
                <button onClick={handleSubmitPasswordChange} disabled={isPasswordSaving} style={{ flex: 1, padding: '10px', backgroundColor: 'var(--primary-color)', color: '#ffffff', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>Mentés</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {editModalData && !confirmModalData && !completeModalData && (
        <div className="custom-modal-overlay" onClick={closeModals}>
          <div className="custom-modal-box" onClick={(e) => e.stopPropagation()} style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
            <h2 className="modal-alert-title" style={{ color: 'var(--text-main)' }}>Státusz módosítása</h2>
            <p className="modal-alert-text" style={{ marginBottom: '10px', color: 'var(--text-muted)' }}>
              Jelenlegi státusz: <strong style={{ color: 'var(--primary-color)', textTransform: 'uppercase' }}>{editModalData.munka_statusz}</strong>
            </p>

            <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', marginTop: '20px' }}>
              {editModalData.munka_statusz?.toLowerCase() === 'elfogadva' && (
                <>
                  <button className="modal-btn-success" onClick={() => initiateStatusChange(editModalData.munka_id, editModalData.diak_id, 'teljesítve')}>Teljesítve</button>
                  <button className="modal-btn-back" style={{ color: '#ef4444', borderColor: '#ef4444' }} onClick={() => initiateStatusChange(editModalData.munka_id, editModalData.diak_id, 'elutasítva')}>Elutasítás</button>
                </>
              )}
              {editModalData.munka_statusz?.toLowerCase() === 'elutasítva' && (
                <button className="modal-btn-login" onClick={() => initiateStatusChange(editModalData.munka_id, editModalData.diak_id, 'elfogadva')}>Elfogadás</button>
              )}
              {editModalData.munka_statusz?.toLowerCase() === 'teljesítve' && (
                <p style={{ color: '#16a34a', fontWeight: 'bold', width: '100%' }}>✅ Ez a munka már sikeresen le van zárva!</p>
              )}
            </div>
            <button className="modal-btn-back" style={{ marginTop: '20px', width: '100%', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', borderColor: 'var(--border-color)' }} onClick={closeModals}>Bezárás</button>
          </div>
        </div>
      )}

      {confirmModalData && (
        <div className="custom-modal-overlay" onClick={closeModals}>
          <div className="custom-modal-box" onClick={(e) => e.stopPropagation()} style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
            <div className="modal-icon-container" style={{ backgroundColor: '#fef9c3', color: '#eab308', margin: '0 auto 20px auto', width: '60px', height: '60px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span style={{ fontSize: '30px' }}>⚠️</span></div>
            <h2 className="modal-alert-title" style={{ color: 'var(--text-main)' }}>Biztos vagy benne?</h2>
            <div className="modal-alert-buttons" style={{ display: 'flex', gap: '15px', justifyContent: 'center', marginTop: '20px' }}>
              <button className="modal-btn-back" style={{ backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', borderColor: 'var(--border-color)' }} onClick={closeModals}>Mégse</button>
              <button className={confirmModalData.ujStatusz === 'elutasítva' ? 'modal-btn-back' : 'modal-btn-success'} style={confirmModalData.ujStatusz === 'elutasítva' ? { backgroundColor: '#ef4444', color: 'white', border: 'none' } : {}} onClick={confirmStatusChange}>Igen, módosítom</button>
            </div>
          </div>
        </div>
      )}

      {completeModalData && (
        <div className="custom-modal-overlay" onClick={closeModals}>
          <div className="custom-modal-box" onClick={(e) => e.stopPropagation()} style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', maxWidth: '500px' }}>
            <div className="modal-icon-container" style={{ backgroundColor: 'var(--badge-success-bg)', color: 'var(--badge-success-text)', margin: '0 auto 20px auto', width: '60px', height: '60px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span style={{ fontSize: '30px' }}>📄</span></div>
            <h2 className="modal-alert-title" style={{ color: 'var(--text-main)' }}>Igazolás kiállítása</h2>
            <p className="modal-alert-text" style={{ color: 'var(--text-muted)', marginBottom: '20px' }}>Kérlek, add meg a formátumot és írd alá alul.</p>

            <div style={{ marginBottom: '20px', textAlign: 'left' }}>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 'bold', marginBottom: '8px', color: 'var(--text-muted)' }}>Formátum (nap * óra)</label>
              <input type="text" placeholder="pl. 2*4" value={hoursFormat} onChange={(e) => { setHoursFormat(e.target.value); setHoursError(''); }} style={{ width: '100%', padding: '12px', borderRadius: '8px', outline: 'none', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', border: `1px solid ${hoursError ? 'var(--danger-color)' : 'var(--border-color)'}`, fontSize: '16px', textAlign: 'center', letterSpacing: '2px', fontWeight: 'bold' }} />
            </div>

            <div style={{ marginBottom: '20px', textAlign: 'left' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '8px' }}>
                <label style={{ fontSize: '13px', fontWeight: 'bold', color: 'var(--text-muted)' }}>Rajzold ide az aláírásod</label>
                <button onClick={clearSignature} style={{ background: 'none', border: 'none', color: 'var(--danger-color)', fontSize: '12px', cursor: 'pointer', textDecoration: 'underline', fontWeight: 'bold' }}>Törlés</button>
              </div>
              <div style={{ border: '2px dashed var(--border-color)', borderRadius: '8px', backgroundColor: '#ffffff', overflow: 'hidden' }}>
                <SignatureCanvas ref={sigCanvasRef} penColor="black" canvasProps={{ width: 450, height: 150, className: 'sigCanvas' }} />
              </div>
            </div>

            {hoursError && <div style={{ color: 'var(--danger-color)', fontSize: '13px', fontWeight: 'bold', marginBottom: '15px', textAlign: 'center' }}>❌ {hoursError}</div>}

            <div className="modal-alert-buttons" style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
              <button className="modal-btn-back" style={{ backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', borderColor: 'var(--border-color)' }} onClick={closeModals}>Mégse</button>
              <button className="modal-btn-success" onClick={handleIssueDocument}>Véglegesítés és Küldés</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}