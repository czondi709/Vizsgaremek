import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import LandingPage from "./LandingPage";
import Login from "./Vendég/Login";
import Munkak from "./Munka/Munkak";
import Cegeknek from "./Other/Cegeknek";
import Rolunk from "./Other/Rolunk";
import Segitseg from "./Other/Segitseg";
import StudentDashboard from "./Diák/StudentDashboard";
import CompanyDashboard from "./Cég/CompanyDashboard";
import UjHirdetes from "./Munka/UjHirdetes";
import JobDetails from "./Munka/JobDetails";
import MunkaSzerkesztes from './Cég/MunkaSzerkesztes';
import AdminDashboard from "./Admin/AdminDashboard";
import { ToastProvider } from "./Other/ToastContext";
import "./App.css";
import { useEffect } from "react";


const AdminRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  const userType = localStorage.getItem("userType");


  if (!token || userType !== "admin") {
    return <Navigate to="/" replace />;
  }


  return children;
};

function App() {
  useEffect(() => {
    if (localStorage.getItem('theme') === 'dark') {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  }, []);

  return (
    <ToastProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/munkak" element={<Munkak />} />
          <Route path="/cegeknek" element={<Cegeknek />} />
          <Route path="/rolunk" element={<Rolunk />} />
          <Route path="/segitseg" element={<Segitseg />} />

          <Route path="/profil" element={<StudentDashboard />} />
          <Route path="/ceg-profil" element={<CompanyDashboard />} />
          <Route path="/uj-hirdetes" element={<UjHirdetes />} />
          <Route path="/munka-reszletek/:id" element={<JobDetails />} />
          <Route path="/munka-szerkesztes/:id" element={<MunkaSzerkesztes />} />


          <Route
            path="/admin"
            element={
              <AdminRoute>
                <AdminDashboard />
              </AdminRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </ToastProvider>
  );
}

export default App;