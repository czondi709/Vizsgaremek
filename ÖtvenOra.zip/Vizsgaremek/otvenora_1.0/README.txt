Parancsok a működéshez:
npm i
npm i axios
npm i jspdf jspdf-autotable
npm i react-signature-canvas
npm run dev


Belépési adatok:

Diák 
email: gombasgero2006@gmail.com
jelszó: Gombasgergo1!


Admin
sima főoldalon F12 -> Application -> LocalStorage -> http://localhost:5173
Key		Value
token		12345
userType	admin	

Majd utána a keresési cím a következő legyen
http://localhost:5173/admin
